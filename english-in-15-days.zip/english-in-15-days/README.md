# 🇬🇧 English in 15 Days

A modern, mobile-first React web app that helps complete beginners learn practical English speaking skills in just 15 days — using AI, voice recognition, and gamification.

---

## 🚀 Features

- **15-Day Structured Program** — Each day unlocks only after completing all tasks + 70% quiz score
- **Voice-Based Learning** — Web Speech API for real-time speech recognition and text-to-speech
- **AI Speaking Coach** — Claude AI gives personalized grammar and pronunciation feedback
- **Gamification** — XP points, streak tracking, achievement badges, motivational messages
- **6 Daily Activities** — Vocabulary flashcards, grammar lessons, listening exercises, speaking practice, quiz, challenge
- **Dark/Light Mode** — Full theme support with beautiful purple/violet palette
- **Mobile-First** — Optimized for 430px mobile viewport, works on any device
- **Offline-Ready** — Lessons stored in JS, no internet required for core learning
- **Progressive Unlocking** — Day N+1 unlocks only after passing quiz (≥70%) + speaking exercise

---

## 📱 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18 |
| Routing/State | React Context + useReducer |
| Speech | Web Speech API (built-in browser) |
| AI Feedback | Anthropic Claude API |
| Storage | localStorage (no backend needed) |
| Styling | Pure CSS with CSS variables |
| Animations | CSS keyframes + transitions |
| Fonts | Syne (display) + DM Sans (body) |

---

## 🛠️ Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Start development server
```bash
npm start
```

### 3. Open in browser
```
http://localhost:3000
```

> **Note:** For voice features, use **Google Chrome** (best Web Speech API support).

---

## 📁 Project Structure

```
src/
├── context/
│   └── AppContext.js          # Global state management
├── data/
│   └── lessons.js             # All 15 days of lesson content
├── hooks/
│   └── useSpeech.js           # TTS, STT, pronunciation scoring
├── services/
│   └── aiCoach.js             # Claude AI integration
├── screens/
│   ├── Onboarding.js          # Welcome + name + goal setup
│   ├── Dashboard.js           # Home, Lessons, Badges, Coach tabs
│   ├── LessonScreen.js        # Lesson orchestrator (6 steps)
│   └── DayComplete.js         # Celebration + stats screen
├── components/lesson/
│   ├── VocabularyStep.js      # Flashcard-based vocab learning
│   ├── GrammarStep.js         # Grammar rules + examples
│   ├── ListeningStep.js       # TTS listening exercise
│   ├── SpeakingStep.js        # STT + AI feedback speaking
│   ├── QuizStep.js            # Multiple choice quiz (min 70%)
│   └── ChallengeStep.js       # Daily real-world challenge
├── App.js                     # Screen router
└── index.css                  # Design tokens + global styles
```

---

## 📅 15-Day Curriculum

| Day | Topic |
|-----|-------|
| 1 | Greetings & Introductions |
| 2 | Daily Conversations |
| 3 | Family & Friends |
| 4 | Numbers & Time |
| 5 | Food & Ordering |
| 6 | Shopping |
| 7 | Travel Basics |
| 8 | Work & School |
| 9 | Asking Questions |
| 10 | Describing People & Places |
| 11 | Everyday Situations |
| 12 | Telephone Conversations |
| 13 | Social Communication |
| 14 | Real-Life Practice |
| 15 | Final Speaking Assessment |

---

## 🎤 Voice Features

Speech recognition uses the **Web Speech API** (built into Chrome/Edge/Safari).

- **Listening:** Click the 🎤 microphone button and speak
- **TTS Playback:** Click any ▶ button to hear words/sentences
- **Scoring:** Pronunciation scored 0–100% based on word overlap with target
- **AI Feedback:** Claude API analyzes grammar, vocabulary, fluency

> If speech recognition doesn't work: use Chrome browser, allow microphone access

---

## 🏆 Gamification System

- **XP:** +100 base per day + quiz score bonus
- **Streaks:** Daily login tracking
- **Badges:** 8 achievement badges (First Step, Week Warrior, Graduate, etc.)
- **Progression:** Day N+1 locked until N is fully complete

---

## 🔧 Build for Production

```bash
npm run build
```

Static files output to `build/` folder — deploy to any static host (Netlify, Vercel, GitHub Pages).

---

## 🌐 GitHub Pages Deployment

```bash
npm install gh-pages --save-dev
```

Add to `package.json`:
```json
"homepage": "https://yourusername.github.io/english-in-15-days",
"scripts": {
  "predeploy": "npm run build",
  "deploy": "gh-pages -d build"
}
```

```bash
npm run deploy
```

---

## 📄 License

MIT — free to use, modify, and distribute.

---

**Built with ❤️ for English learners everywhere. Speak with confidence! 🌍**
