import React, { useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import Onboarding from './screens/Onboarding';
import Dashboard from './screens/Dashboard';
import LessonScreen from './screens/LessonScreen';
import DayComplete from './screens/DayComplete';
import './index.css';

// Confetti component (pure CSS + JS)
function Confetti() {
  return (
    <div className="confetti-overlay" aria-hidden="true">
      {Array.from({ length: 40 }, (_, i) => (
        <div
          key={i}
          className="confetti-piece"
          style={{
            left: `${Math.random() * 100}%`,
            animationDelay: `${Math.random() * 2}s`,
            animationDuration: `${2 + Math.random() * 2}s`,
            background: ['#7c5cfc','#c084fc','#f59e0b','#10b981','#3b82f6','#ef4444'][i % 6]
          }}
        />
      ))}
    </div>
  );
}

function AppInner() {
  const { state, dispatch } = useApp();
  const { screen, showConfetti } = state;

  // Apply theme on mount
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', state.theme);
  }, [state.theme]);

  // Auto-hide confetti
  useEffect(() => {
    if (showConfetti) {
      const t = setTimeout(() => dispatch({ type: 'HIDE_CONFETTI' }), 4000);
      return () => clearTimeout(t);
    }
  }, [showConfetti, dispatch]);

  const renderScreen = () => {
    switch (screen) {
      case 'onboarding': return <Onboarding />;
      case 'dashboard': return <Dashboard />;
      case 'lesson': return <LessonScreen />;
      case 'day-complete': return <DayComplete />;
      default: return <Onboarding />;
    }
  };

  return (
    <div className="app-root">
      {showConfetti && <Confetti />}
      <div className="screen-transition" key={screen}>
        {renderScreen()}
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppInner />
    </AppProvider>
  );
}
