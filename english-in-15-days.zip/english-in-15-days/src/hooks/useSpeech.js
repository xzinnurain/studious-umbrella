import { useState, useCallback, useRef } from 'react';

// ── TEXT-TO-SPEECH ──────────────────────────────────────────────
export function useTTS() {
  const [speaking, setSpeaking] = useState(false);
  const utteranceRef = useRef(null);

  const speak = useCallback((text, options = {}) => {
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = options.lang || 'en-US';
    utterance.rate = options.rate || 0.85;
    utterance.pitch = options.pitch || 1;
    utterance.volume = options.volume || 1;

    // Prefer a clear English voice
    const voices = window.speechSynthesis.getVoices();
    const preferred = voices.find(v =>
      v.lang === 'en-US' && (v.name.includes('Google') || v.name.includes('Natural'))
    ) || voices.find(v => v.lang.startsWith('en'));
    if (preferred) utterance.voice = preferred;

    utterance.onstart = () => setSpeaking(true);
    utterance.onend = () => setSpeaking(false);
    utterance.onerror = () => setSpeaking(false);

    utteranceRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  }, []);

  const stop = useCallback(() => {
    window.speechSynthesis?.cancel();
    setSpeaking(false);
  }, []);

  return { speak, stop, speaking };
}

// ── SPEECH-TO-TEXT ──────────────────────────────────────────────
export function useSTT() {
  const [listening, setListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [error, setError] = useState(null);
  const recognitionRef = useRef(null);

  const startListening = useCallback(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setError('Speech recognition not supported in this browser. Please use Chrome.');
      return;
    }

    setTranscript('');
    setError(null);

    const recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;
    recognition.continuous = false;

    recognition.onstart = () => setListening(true);

    recognition.onresult = (event) => {
      const result = Array.from(event.results)
        .map(r => r[0].transcript)
        .join('');
      setTranscript(result);
    };

    recognition.onerror = (event) => {
      setError(event.error === 'no-speech' ? 'No speech detected. Try again!' : `Error: ${event.error}`);
      setListening(false);
    };

    recognition.onend = () => setListening(false);

    recognitionRef.current = recognition;
    recognition.start();
  }, []);

  const stopListening = useCallback(() => {
    recognitionRef.current?.stop();
    setListening(false);
  }, []);

  return { listening, transcript, error, startListening, stopListening, setTranscript };
}

// ── PRONUNCIATION SCORER ───────────────────────────────────────
export function scorePronunciation(spoken, target) {
  if (!spoken || !target) return 0;

  const normalize = (s) => s.toLowerCase()
    .replace(/[^a-z0-9\s]/g, '')
    .split(/\s+/)
    .filter(Boolean);

  const spokenWords = normalize(spoken);
  const targetWords = normalize(target);

  if (targetWords.length === 0) return 0;

  // Count matching words (order-independent for partial credit)
  let matches = 0;
  const targetCopy = [...targetWords];
  for (const word of spokenWords) {
    const idx = targetCopy.indexOf(word);
    if (idx !== -1) {
      matches++;
      targetCopy.splice(idx, 1);
    }
  }

  // Word overlap score
  const overlapScore = Math.min(matches / targetWords.length, 1) * 70;

  // Length similarity score (penalize too short/long)
  const lengthRatio = Math.min(spokenWords.length, targetWords.length) /
    Math.max(spokenWords.length, targetWords.length, 1);
  const lengthScore = lengthRatio * 30;

  return Math.round(overlapScore + lengthScore);
}
