import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { BADGES } from '../data/lessons';

const AppContext = createContext();

const initialState = {
  // User
  user: JSON.parse(localStorage.getItem('user')) || null,
  theme: localStorage.getItem('theme') || 'dark',

  // Progress
  progress: JSON.parse(localStorage.getItem('progress')) || {
    currentDay: 1,
    completedDays: [],
    xp: 0,
    streak: 0,
    lastActiveDate: null,
    speakingScores: [],
    perfectQuizzes: 0,
    badges: [],
    dailyCompleted: {}
  },

  // Current lesson state
  currentLesson: null,
  lessonStep: 'vocabulary', // vocabulary | grammar | listening | speaking | quiz | challenge
  lessonProgress: {
    vocabulary: false,
    grammar: false,
    listening: false,
    speaking: false,
    quiz: false,
    challenge: false
  },

  // UI
  screen: JSON.parse(localStorage.getItem('user')) ? 'dashboard' : 'onboarding',
  quizScore: null,
  speakingScore: null,
  showConfetti: false,
  notification: null
};

function reducer(state, action) {
  switch (action.type) {
    case 'SET_USER':
      return { ...state, user: action.payload, screen: 'dashboard' };

    case 'SET_THEME':
      return { ...state, theme: action.payload };

    case 'SET_SCREEN':
      return { ...state, screen: action.payload };

    case 'START_LESSON':
      return {
        ...state,
        screen: 'lesson',
        currentLesson: action.payload,
        lessonStep: 'vocabulary',
        lessonProgress: {
          vocabulary: false, grammar: false, listening: false,
          speaking: false, quiz: false, challenge: false
        },
        quizScore: null,
        speakingScore: null
      };

    case 'SET_LESSON_STEP':
      return { ...state, lessonStep: action.payload };

    case 'COMPLETE_STEP':
      return {
        ...state,
        lessonProgress: { ...state.lessonProgress, [action.payload]: true }
      };

    case 'SET_QUIZ_SCORE':
      const isPerfect = action.payload === 100;
      return {
        ...state,
        quizScore: action.payload,
        progress: {
          ...state.progress,
          perfectQuizzes: isPerfect
            ? state.progress.perfectQuizzes + 1
            : state.progress.perfectQuizzes
        }
      };

    case 'SET_SPEAKING_SCORE':
      return {
        ...state,
        speakingScore: action.payload,
        progress: {
          ...state.progress,
          speakingScores: [...state.progress.speakingScores, action.payload]
        }
      };

    case 'COMPLETE_DAY': {
      const day = action.payload;
      const alreadyCompleted = state.progress.completedDays.includes(day);
      if (alreadyCompleted) return state;

      const today = new Date().toDateString();
      const lastActive = state.progress.lastActiveDate;
      const yesterday = new Date(Date.now() - 86400000).toDateString();
      const newStreak = lastActive === yesterday || lastActive === today
        ? state.progress.streak + (lastActive === today ? 0 : 1)
        : 1;

      const newProgress = {
        ...state.progress,
        completedDays: [...state.progress.completedDays, day],
        currentDay: Math.min(day + 1, 15),
        xp: state.progress.xp + 100 + (state.quizScore || 0),
        streak: newStreak,
        lastActiveDate: today,
        dailyCompleted: { ...state.progress.dailyCompleted, [day]: today }
      };

      // Check badges
      const newBadges = BADGES
        .filter(b => !newProgress.badges.includes(b.id) && b.condition(newProgress))
        .map(b => b.id);
      newProgress.badges = [...newProgress.badges, ...newBadges];

      return {
        ...state,
        progress: newProgress,
        showConfetti: true,
        screen: 'day-complete'
      };
    }

    case 'HIDE_CONFETTI':
      return { ...state, showConfetti: false };

    case 'SHOW_NOTIFICATION':
      return { ...state, notification: action.payload };

    case 'HIDE_NOTIFICATION':
      return { ...state, notification: null };

    case 'RESET_PROGRESS':
      return { ...state, progress: initialState.progress, user: null, screen: 'onboarding' };

    default:
      return state;
  }
}

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  // Persist to localStorage
  useEffect(() => {
    if (state.user) localStorage.setItem('user', JSON.stringify(state.user));
    else localStorage.removeItem('user');
  }, [state.user]);

  useEffect(() => {
    localStorage.setItem('progress', JSON.stringify(state.progress));
  }, [state.progress]);

  useEffect(() => {
    localStorage.setItem('theme', state.theme);
    document.documentElement.setAttribute('data-theme', state.theme);
  }, [state.theme]);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
}

export const useApp = () => useContext(AppContext);
