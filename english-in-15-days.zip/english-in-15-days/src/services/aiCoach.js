// AI Speaking Coach — calls Claude API for feedback and conversation

const SYSTEM_PROMPT = `You are an encouraging English speaking coach for complete beginners. 
Your student is learning English from scratch in 15 days.

Your role:
- Give warm, encouraging feedback on their spoken English
- Point out 1-2 specific mistakes gently (grammar or vocabulary)
- Suggest a better way to say something if needed
- Keep responses SHORT (2-4 sentences max)
- Use simple English they can understand
- Always end with encouragement
- Score their response from 0-100 for grammar, vocabulary, fluency

When scoring, respond in this JSON format:
{
  "feedback": "Your encouraging feedback here.",
  "correction": "If there's a mistake: 'Instead of X, try saying Y.' Otherwise leave empty.",
  "better_phrase": "A better/more natural way to say it (optional)",
  "scores": {
    "grammar": 85,
    "vocabulary": 80, 
    "fluency": 75,
    "overall": 80
  }
}`;

export async function getAIFeedback(userSpeech, context, dayTopic) {
  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        system: SYSTEM_PROMPT,
        messages: [{
          role: 'user',
          content: `Day topic: ${dayTopic}
Context/prompt: ${context}
Student said: "${userSpeech}"

Please analyze and give feedback in the JSON format.`
        }]
      })
    });

    const data = await response.json();
    const text = data.content?.[0]?.text || '';

    // Parse JSON from response
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0]);
    }

    // Fallback
    return {
      feedback: "Great effort! Keep practicing and you'll improve every day.",
      correction: "",
      better_phrase: "",
      scores: { grammar: 70, vocabulary: 70, fluency: 70, overall: 70 }
    };
  } catch (err) {
    console.error('AI feedback error:', err);
    return {
      feedback: "Excellent work! Your English is improving. Keep going!",
      correction: "",
      better_phrase: "",
      scores: { grammar: 75, vocabulary: 75, fluency: 75, overall: 75 }
    };
  }
}

export async function getAIConversation(messages, dayTopic) {
  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        system: `You are a friendly conversation partner helping a beginner learn English. 
Today's topic: ${dayTopic}. 
Keep your responses SHORT (1-2 sentences). Use simple vocabulary. 
If they make a grammar mistake, gently correct it in your reply.
Be warm, patient, and encouraging.`,
        messages: messages.map(m => ({ role: m.role, content: m.content }))
      })
    });

    const data = await response.json();
    return data.content?.[0]?.text || "That's wonderful! Can you tell me more?";
  } catch (err) {
    const fallbacks = [
      "That's great! Can you tell me more about that?",
      "Interesting! How do you feel about that?",
      "Wonderful! What do you think about English so far?",
      "Good job! Keep practicing every day!"
    ];
    return fallbacks[Math.floor(Math.random() * fallbacks.length)];
  }
}

export async function generateFinalReport(allScores, userName) {
  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        system: `You generate encouraging final assessment reports for English learners. 
Be warm, specific, and motivating. Keep it to 3-4 sentences.
Respond in JSON: { "summary": "...", "strengths": ["...", "..."], "nextSteps": ["...", "..."], "fluencyLevel": "Beginner|Elementary|Pre-Intermediate" }`,
        messages: [{
          role: 'user',
          content: `Student: ${userName}
Scores over 15 days: ${JSON.stringify(allScores)}
Average speaking score: ${allScores.reduce((a, b) => a + b, 0) / allScores.length || 75}
Generate a personalized final report.`
        }]
      })
    });

    const data = await response.json();
    const text = data.content?.[0]?.text || '';
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) return JSON.parse(jsonMatch[0]);
  } catch (err) {}

  return {
    summary: `Congratulations ${userName}! You've completed the 15-day English challenge and made incredible progress.`,
    strengths: ["Consistent daily practice", "Improved speaking confidence", "Strong vocabulary foundation"],
    nextSteps: ["Practice daily conversations", "Watch English TV shows", "Join an English speaking group"],
    fluencyLevel: "Elementary"
  };
}
