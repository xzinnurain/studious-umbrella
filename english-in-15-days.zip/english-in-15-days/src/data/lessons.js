export const DAYS_DATA = [
  {
    day: 1,
    title: "Greetings & Introductions",
    emoji: "👋",
    color: "#7c5cfc",
    description: "Learn how to say hello, introduce yourself, and meet new people.",
    vocabulary: [
      { word: "Hello", phonetic: "/həˈloʊ/", meaning: "A greeting", example: "Hello! My name is Alex." },
      { word: "Goodbye", phonetic: "/ˌɡʊdˈbaɪ/", meaning: "Farewell", example: "Goodbye! See you tomorrow." },
      { word: "Please", phonetic: "/pliːz/", meaning: "Polite request word", example: "Can you help me, please?" },
      { word: "Thank you", phonetic: "/ˈθæŋk juː/", meaning: "Express gratitude", example: "Thank you very much!" },
      { word: "Sorry", phonetic: "/ˈsɒri/", meaning: "Apology or excuse", example: "Sorry, I didn't mean that." },
      { word: "My name is", phonetic: "/maɪ neɪm ɪz/", meaning: "Introducing yourself", example: "My name is Sara." },
      { word: "Nice to meet you", phonetic: "/naɪs tə miːt juː/", meaning: "Polite greeting on meeting", example: "Nice to meet you, John!" },
      { word: "How are you", phonetic: "/haʊ ɑːr juː/", meaning: "Asking about well-being", example: "Hi! How are you today?" },
      { word: "I'm fine", phonetic: "/aɪm faɪn/", meaning: "Saying you are well", example: "I'm fine, thank you." },
      { word: "Good morning", phonetic: "/ɡʊd ˈmɔːrnɪŋ/", meaning: "Morning greeting", example: "Good morning, everyone!" }
    ],
    grammar: {
      title: "Verb 'To Be' — Present Tense",
      explanation: "Use 'am', 'is', 'are' to describe yourself and others.",
      rules: [
        "I am → I'm (I am a student)",
        "You are → You're (You are kind)",
        "He/She is → He's/She's (She is my friend)",
        "We/They are → We're/They're (We are happy)"
      ],
      examples: ["I am from Bangladesh.", "She is a teacher.", "They are my friends."]
    },
    listeningText: "Good morning! My name is Emma. I am from London. Nice to meet you! How are you today? I am fine, thank you. Goodbye!",
    speakingPrompt: "Introduce yourself! Say your name, where you are from, and greet someone.",
    speakingTarget: "Hello! My name is [your name]. I am from [your city]. Nice to meet you!",
    quiz: [
      { question: "What do you say when you first meet someone?", options: ["Goodbye", "Nice to meet you", "I'm fine", "See you"], answer: 1 },
      { question: "Which is correct? 'I ___ a student.'", options: ["is", "are", "am", "be"], answer: 2 },
      { question: "How do you greet someone in the morning?", options: ["Good night", "Good morning", "Good evening", "Goodnight"], answer: 1 },
      { question: "What does 'How are you?' mean?", options: ["What is your name?", "Where are you from?", "Are you okay?", "Nice to meet you"], answer: 2 },
      { question: "'Thank you' is used to...", options: ["Say sorry", "Say goodbye", "Express gratitude", "Say hello"], answer: 2 }
    ],
    challenge: "Talk to 3 people today (or practice alone) and introduce yourself in English!"
  },
  {
    day: 2,
    title: "Daily Conversations",
    emoji: "💬",
    color: "#c084fc",
    description: "Practice everyday conversations for any situation.",
    vocabulary: [
      { word: "What time is it?", phonetic: "/wɒt taɪm ɪz ɪt/", meaning: "Asking the time", example: "Excuse me, what time is it?" },
      { word: "Where is", phonetic: "/wɛr ɪz/", meaning: "Asking location", example: "Where is the bathroom?" },
      { word: "Can you help me?", phonetic: "/kæn juː hɛlp miː/", meaning: "Requesting help", example: "Excuse me, can you help me?" },
      { word: "I don't understand", phonetic: "/aɪ doʊnt ʌndəˈstænd/", meaning: "Not understanding", example: "Sorry, I don't understand." },
      { word: "Please speak slowly", phonetic: "/pliːz spiːk ˈsloʊli/", meaning: "Ask to speak slower", example: "Please speak slowly, I'm learning English." },
      { word: "Excuse me", phonetic: "/ɪkˈskjuːz miː/", meaning: "Getting attention/apologizing", example: "Excuse me, where is the exit?" },
      { word: "Of course", phonetic: "/əv kɔːrs/", meaning: "Certainly / Yes", example: "Of course! I'll help you." },
      { word: "No problem", phonetic: "/noʊ ˈprɒbləm/", meaning: "It's okay / You're welcome", example: "Thank you! — No problem!" },
      { word: "I need", phonetic: "/aɪ niːd/", meaning: "Expressing necessity", example: "I need a glass of water." },
      { word: "I want", phonetic: "/aɪ wɒnt/", meaning: "Expressing desire", example: "I want to learn English." }
    ],
    grammar: {
      title: "Present Simple — Questions & Negatives",
      explanation: "Use 'do/does' to ask questions and 'don't/doesn't' to make negatives.",
      rules: [
        "Do you like...? / I don't like...",
        "Does she work? / She doesn't work.",
        "What do you do? (job/habits)",
        "Where does he live?"
      ],
      examples: ["Do you speak English?", "I don't speak French.", "Does she live here?"]
    },
    listeningText: "Excuse me! Can you help me? I'm looking for the train station. Of course! Go straight, then turn left. Thank you so much! No problem. Have a nice day!",
    speakingPrompt: "Ask for directions or help in a public place.",
    speakingTarget: "Excuse me, can you help me? I'm looking for the nearest café.",
    quiz: [
      { question: "'Excuse me' is used to...", options: ["Say goodbye", "Get someone's attention", "Express gratitude", "Introduce yourself"], answer: 1 },
      { question: "How do you ask for help?", options: ["I need you", "Can you help me?", "Help!", "Do help me"], answer: 1 },
      { question: "Which is correct?", options: ["Does you like tea?", "Do you likes tea?", "Do you like tea?", "You like tea?"], answer: 2 },
      { question: "'No problem' means...", options: ["I have a problem", "It's okay", "I don't know", "Please wait"], answer: 1 },
      { question: "What do you say when you don't understand?", options: ["I don't like it", "I don't understand", "I don't want it", "I don't need it"], answer: 1 }
    ],
    challenge: "Have a complete conversation in English today — even with yourself in the mirror!"
  },
  {
    day: 3,
    title: "Family & Friends",
    emoji: "👨‍👩‍👧",
    color: "#f59e0b",
    description: "Talk about your family members and describe relationships.",
    vocabulary: [
      { word: "Mother", phonetic: "/ˈmʌðər/", meaning: "Female parent", example: "My mother is a doctor." },
      { word: "Father", phonetic: "/ˈfɑːðər/", meaning: "Male parent", example: "My father works in a bank." },
      { word: "Brother", phonetic: "/ˈbrʌðər/", meaning: "Male sibling", example: "I have one brother." },
      { word: "Sister", phonetic: "/ˈsɪstər/", meaning: "Female sibling", example: "My sister is 15 years old." },
      { word: "Friend", phonetic: "/frɛnd/", meaning: "A person you like and trust", example: "She is my best friend." },
      { word: "Husband", phonetic: "/ˈhʌzbənd/", meaning: "Married male partner", example: "Her husband is very kind." },
      { word: "Wife", phonetic: "/waɪf/", meaning: "Married female partner", example: "His wife is a teacher." },
      { word: "Son", phonetic: "/sʌn/", meaning: "Male child", example: "They have two sons." },
      { word: "Daughter", phonetic: "/ˈdɔːtər/", meaning: "Female child", example: "My daughter loves music." },
      { word: "Grandparents", phonetic: "/ˈɡrændˌpɛrənts/", meaning: "Parents of parents", example: "My grandparents live in a village." }
    ],
    grammar: {
      title: "Possessive Adjectives",
      explanation: "Use my, your, his, her, our, their to show ownership.",
      rules: [
        "I → my (This is my family)",
        "You → your (What is your mother's name?)",
        "He → his / She → her",
        "We → our / They → their"
      ],
      examples: ["My father is tall.", "Her sister is funny.", "Their house is big."]
    },
    listeningText: "My name is Omar. I have a small family. My mother is a nurse and my father is a teacher. I have one brother and one sister. My sister is my best friend. We love spending time together.",
    speakingPrompt: "Describe your family members to someone.",
    speakingTarget: "I have a [small/big] family. My mother is a [job]. My father is a [job]. I have [number] brothers and [number] sisters.",
    quiz: [
      { question: "What is the female parent called?", options: ["Sister", "Daughter", "Mother", "Wife"], answer: 2 },
      { question: "'Her book' shows that the book belongs to...", options: ["him", "her", "them", "me"], answer: 1 },
      { question: "Which word means a male sibling?", options: ["Father", "Son", "Uncle", "Brother"], answer: 3 },
      { question: "Complete: '___ parents are teachers.'", options: ["My", "Me", "I", "Mine"], answer: 0 },
      { question: "What is the opposite of 'husband'?", options: ["Mother", "Daughter", "Wife", "Sister"], answer: 2 }
    ],
    challenge: "Describe your entire family in English — write it down, then say it out loud!"
  },
  {
    day: 4,
    title: "Numbers & Time",
    emoji: "🕐",
    color: "#10b981",
    description: "Master numbers, dates, and telling the time in English.",
    vocabulary: [
      { word: "One to Ten", phonetic: "/wʌn tə tɛn/", meaning: "1–10 numbers", example: "I have five apples." },
      { word: "Twenty", phonetic: "/ˈtwɛnti/", meaning: "Number 20", example: "I am twenty years old." },
      { word: "Hundred", phonetic: "/ˈhʌndrəd/", meaning: "Number 100", example: "There are one hundred students." },
      { word: "What time is it?", phonetic: "/wɒt taɪm ɪz ɪt/", meaning: "Asking the time", example: "What time is it? It's 3 o'clock." },
      { word: "O'clock", phonetic: "/əˈklɒk/", meaning: "Exact hour", example: "School starts at 8 o'clock." },
      { word: "Half past", phonetic: "/hɑːf pɑːst/", meaning: "30 minutes past", example: "It's half past two." },
      { word: "Quarter to", phonetic: "/ˈkwɔːrtər tə/", meaning: "15 min before hour", example: "It's quarter to five." },
      { word: "Morning / Afternoon / Evening", phonetic: "", meaning: "Parts of the day", example: "Good afternoon!" },
      { word: "Today / Yesterday / Tomorrow", phonetic: "", meaning: "Days relative to now", example: "I'll see you tomorrow." },
      { word: "Week / Month / Year", phonetic: "/wiːk mʌnθ jɪər/", meaning: "Time periods", example: "My birthday is next month." }
    ],
    grammar: {
      title: "Telling Time & Using Numbers",
      explanation: "Say time with 'It is' or 'It's'. Use ordinal numbers for dates.",
      rules: [
        "It's 3 o'clock / It's 3:00",
        "It's half past 4 = It's 4:30",
        "It's quarter to 6 = It's 5:45",
        "Ordinals: first, second, third, fourth..."
      ],
      examples: ["It's ten o'clock.", "Today is the first of January.", "I wake up at half past seven."]
    },
    listeningText: "It's seven o'clock in the morning. Time to wake up! My alarm rings at half past six every day. I have breakfast at seven fifteen. School starts at eight o'clock sharp.",
    speakingPrompt: "Tell the time and describe your daily schedule.",
    speakingTarget: "I wake up at [time]. I have breakfast at [time]. I start work/school at [time].",
    quiz: [
      { question: "What is '3:30' in words?", options: ["Quarter past three", "Half past three", "Three fifteen", "Quarter to four"], answer: 1 },
      { question: "What does 'quarter to 5' mean?", options: ["5:15", "5:45", "4:45", "4:15"], answer: 2 },
      { question: "Say 'the day before today' in one word:", options: ["Tomorrow", "Today", "Yesterday", "Later"], answer: 2 },
      { question: "How do you say the number 100?", options: ["Ten", "Hundred", "Thousand", "Twelve"], answer: 1 },
      { question: "It's 12:00 in the middle of the day. This is...", options: ["Midnight", "Evening", "Noon", "Morning"], answer: 2 }
    ],
    challenge: "Set 5 alarms on your phone and write the time in English for each one!"
  },
  {
    day: 5,
    title: "Food & Ordering",
    emoji: "🍽️",
    color: "#ef4444",
    description: "Order food at a restaurant and talk about what you eat.",
    vocabulary: [
      { word: "Menu", phonetic: "/ˈmɛnjuː/", meaning: "List of food options", example: "Can I see the menu, please?" },
      { word: "Order", phonetic: "/ˈɔːrdər/", meaning: "Request food", example: "I'd like to order, please." },
      { word: "Hungry", phonetic: "/ˈhʌŋɡri/", meaning: "Needing food", example: "I'm very hungry!" },
      { word: "Delicious", phonetic: "/dɪˈlɪʃəs/", meaning: "Very tasty", example: "This food is delicious!" },
      { word: "Bill / Check", phonetic: "/bɪl/", meaning: "Payment request", example: "Can I have the bill, please?" },
      { word: "Vegetarian", phonetic: "/ˌvɛdʒɪˈtɛriən/", meaning: "No meat diet", example: "Do you have vegetarian options?" },
      { word: "I would like", phonetic: "/aɪ wʊd laɪk/", meaning: "Polite way to request", example: "I would like a coffee, please." },
      { word: "Spicy", phonetic: "/ˈspaɪsi/", meaning: "Hot / with chili", example: "Is this dish spicy?" },
      { word: "Drink", phonetic: "/drɪŋk/", meaning: "Beverage", example: "What drinks do you have?" },
      { word: "Table for two", phonetic: "/ˈteɪbəl fər tuː/", meaning: "Reservation for 2 people", example: "A table for two, please." }
    ],
    grammar: {
      title: "Modal Verb: 'Would Like'",
      explanation: "'Would like' is a polite way to say what you want.",
      rules: [
        "I would like... = I'd like...",
        "Would you like...? (offering)",
        "More formal than 'I want'",
        "Use for food, drinks, requests"
      ],
      examples: ["I'd like a cup of tea.", "Would you like some water?", "We'd like a table by the window."]
    },
    listeningText: "Welcome to Green Garden Restaurant! Can I take your order? Yes, I'd like the grilled chicken with rice, please. And to drink? I'd like a lemon juice. Would you like anything else? No thank you. Enjoy your meal!",
    speakingPrompt: "Order a meal at a restaurant.",
    speakingTarget: "I'd like [food item] and [drink], please. How much is that?",
    quiz: [
      { question: "How do you politely ask for the bill?", options: ["Give me money!", "Bill now!", "Can I have the bill, please?", "Pay time!"], answer: 2 },
      { question: "'I'd like' is short for:", options: ["I do like", "I would like", "I did like", "I will like"], answer: 1 },
      { question: "What does 'delicious' mean?", options: ["Expensive", "Spicy", "Very tasty", "Cold"], answer: 2 },
      { question: "'Would you like some tea?' is...", options: ["Rude", "A question about tea", "An order", "A complaint"], answer: 1 },
      { question: "A 'vegetarian' does NOT eat:", options: ["Vegetables", "Rice", "Meat", "Fruit"], answer: 2 }
    ],
    challenge: "Go to a restaurant or café and order entirely in English!"
  },
  {
    day: 6,
    title: "Shopping",
    emoji: "🛍️",
    color: "#f59e0b",
    description: "Shop confidently — ask prices, sizes, and negotiate.",
    vocabulary: [
      { word: "How much?", phonetic: "/haʊ mʌtʃ/", meaning: "Asking price", example: "How much does this cost?" },
      { word: "Too expensive", phonetic: "/tuː ɪkˈspɛnsɪv/", meaning: "Price is too high", example: "That's too expensive for me." },
      { word: "Discount", phonetic: "/ˈdɪskaʊnt/", meaning: "Price reduction", example: "Is there a discount today?" },
      { word: "Size", phonetic: "/saɪz/", meaning: "Measurement of clothing", example: "What size is this shirt?" },
      { word: "Try on", phonetic: "/traɪ ɒn/", meaning: "Wear to check fit", example: "Can I try this on?" },
      { word: "Receipt", phonetic: "/rɪˈsiːt/", meaning: "Payment proof", example: "Can I have a receipt?" },
      { word: "Sale", phonetic: "/seɪl/", meaning: "Items at lower prices", example: "Is this shirt on sale?" },
      { word: "Cashier", phonetic: "/kæˈʃɪər/", meaning: "Person who takes payment", example: "Please pay at the cashier." },
      { word: "Credit card", phonetic: "/ˈkrɛdɪt kɑːrd/", meaning: "Payment card", example: "Can I pay by credit card?" },
      { word: "Change", phonetic: "/tʃeɪndʒ/", meaning: "Money returned after payment", example: "Here is your change." }
    ],
    grammar: {
      title: "Comparatives & Superlatives",
      explanation: "Compare things using -er/more and the -est/most.",
      rules: [
        "cheap → cheaper → cheapest",
        "expensive → more expensive → most expensive",
        "This shirt is cheaper than that one.",
        "That is the most expensive item."
      ],
      examples: ["This bag is bigger than that one.", "I want the cheapest option.", "Is there a better price?"]
    },
    listeningText: "Excuse me, how much is this jacket? It's fifty dollars. That's a bit expensive. Do you have a cheaper one? Yes, this one is thirty dollars. Can I try it on? Of course! The fitting room is over there.",
    speakingPrompt: "Ask about prices and try to get a discount.",
    speakingTarget: "How much is this? Is there a discount? Can I try it on?",
    quiz: [
      { question: "How do you ask the price of something?", options: ["What is this?", "How much?", "Is this good?", "I want this."], answer: 1 },
      { question: "'Cheaper' is the ___ form of 'cheap'.", options: ["Superlative", "Plural", "Comparative", "Negative"], answer: 2 },
      { question: "What does 'try on' mean in a shop?", options: ["Buy it", "Return it", "Wear to check fit", "Ask the price"], answer: 2 },
      { question: "The cheapest = the ___ expensive.", options: ["More", "Most", "Less", "Least"], answer: 3 },
      { question: "'Can I have a receipt?' means you want...", options: ["A discount", "Proof of payment", "A refund", "A new item"], answer: 1 }
    ],
    challenge: "Visit a shop and ask prices, compare items, or ask for a discount in English!"
  },
  {
    day: 7,
    title: "Travel Basics",
    emoji: "✈️",
    color: "#3b82f6",
    description: "Navigate airports, hotels, and new cities in English.",
    vocabulary: [
      { word: "Passport", phonetic: "/ˈpɑːspɔːrt/", meaning: "Travel ID document", example: "Please show your passport." },
      { word: "Boarding pass", phonetic: "/ˈbɔːrdɪŋ pɑːs/", meaning: "Ticket to board plane", example: "Where is my boarding pass?" },
      { word: "Check in", phonetic: "/tʃɛk ɪn/", meaning: "Register at hotel/airport", example: "I'd like to check in, please." },
      { word: "Departure", phonetic: "/dɪˈpɑːrtʃər/", meaning: "Leaving time/place", example: "What is the departure gate?" },
      { word: "Arrival", phonetic: "/əˈraɪvəl/", meaning: "Reaching a place", example: "The arrival is at 3pm." },
      { word: "Platform", phonetic: "/ˈplætfɔːrm/", meaning: "Train boarding area", example: "The train is on platform 5." },
      { word: "Single/Return ticket", phonetic: "", meaning: "One way / round trip", example: "A return ticket to London, please." },
      { word: "Hotel room", phonetic: "/hoʊˈtɛl ruːm/", meaning: "Room to stay in", example: "I have a reservation for one room." },
      { word: "Lost", phonetic: "/lɒst/", meaning: "Unable to find way", example: "I'm lost. Can you help me?" },
      { word: "Map", phonetic: "/mæp/", meaning: "Visual guide to place", example: "Can I have a map of the city?" }
    ],
    grammar: {
      title: "Future Tense with 'Will' & 'Going to'",
      explanation: "Use 'will' for decisions made now, 'going to' for plans.",
      rules: [
        "I will take a taxi. (spontaneous decision)",
        "I am going to fly tomorrow. (plan)",
        "Will you help me? (question)",
        "The plane will arrive at 5pm."
      ],
      examples: ["I'm going to visit Paris.", "The train will leave soon.", "Will you come with me?"]
    },
    listeningText: "Welcome to London Heathrow Airport. Please have your passport and boarding pass ready. Flight BA204 to New York is now boarding at Gate 12. Please proceed to the departure lounge.",
    speakingPrompt: "Ask for help at an airport or train station.",
    speakingTarget: "Excuse me, where is Gate 12? What time does the train to [city] leave?",
    quiz: [
      { question: "What document do you need for international travel?", options: ["Driver's license", "Passport", "Bank card", "Student card"], answer: 1 },
      { question: "'I'm going to fly' describes a...", options: ["Past event", "Surprise", "Future plan", "Question"], answer: 2 },
      { question: "What is a 'return ticket'?", options: ["A one-way trip", "A round trip", "A refund ticket", "A hotel booking"], answer: 1 },
      { question: "'Departure' means:", options: ["Arriving somewhere", "Leaving a place", "Checking in", "Boarding"], answer: 1 },
      { question: "If you are lost, you say:", options: ["I am late.", "I am lost.", "I am tired.", "I am ready."], answer: 1 }
    ],
    challenge: "Plan an imaginary trip in English — describe where you are going, how, and when!"
  },
  {
    day: 8,
    title: "Work & School",
    emoji: "💼",
    color: "#10b981",
    description: "Talk about your job, education, and professional life.",
    vocabulary: [
      { word: "Job / Profession", phonetic: "/dʒɒb/", meaning: "Work or occupation", example: "What is your job?" },
      { word: "Office", phonetic: "/ˈɒfɪs/", meaning: "Workplace building", example: "I work in an office." },
      { word: "Meeting", phonetic: "/ˈmiːtɪŋ/", meaning: "Gathering to discuss", example: "I have a meeting at noon." },
      { word: "Deadline", phonetic: "/ˈdɛdlaɪn/", meaning: "Final date to finish work", example: "The deadline is Friday." },
      { word: "Colleague", phonetic: "/ˈkɒliːɡ/", meaning: "A person you work with", example: "My colleague is very helpful." },
      { word: "Manager", phonetic: "/ˈmænɪdʒər/", meaning: "Person who leads a team", example: "My manager is strict but fair." },
      { word: "University", phonetic: "/ˌjuːnɪˈvɜːrsɪti/", meaning: "Higher education school", example: "I study at Dhaka University." },
      { word: "Subject", phonetic: "/ˈsʌbdʒɪkt/", meaning: "Topic studied in school", example: "My favorite subject is math." },
      { word: "Exam", phonetic: "/ɪɡˈzæm/", meaning: "Test of knowledge", example: "I have an exam next week." },
      { word: "Graduate", phonetic: "/ˈɡrædʒuɪt/", meaning: "Complete school/university", example: "I will graduate next year." }
    ],
    grammar: {
      title: "Present Continuous — What's Happening Now",
      explanation: "Use 'am/is/are + verb-ing' for actions happening right now.",
      rules: [
        "I am working on a project.",
        "She is studying for the exam.",
        "They are having a meeting.",
        "What are you doing?"
      ],
      examples: ["I'm sending an email.", "My boss is talking on the phone.", "We are preparing the report."]
    },
    listeningText: "Good morning everyone! Welcome to our weekly team meeting. This week's deadline is on Thursday. Please make sure your reports are ready. Are there any questions? Yes — what is the presentation about?",
    speakingPrompt: "Describe your job or school life to a colleague.",
    speakingTarget: "I work as a [job] / I study [subject]. Currently I am working on [project].",
    quiz: [
      { question: "A 'colleague' is someone who...", options: ["Lives with you", "Works with you", "Teaches you", "Manages you"], answer: 1 },
      { question: "'I am studying' uses which tense?", options: ["Past Simple", "Future", "Present Continuous", "Present Perfect"], answer: 2 },
      { question: "A 'deadline' is:", options: ["A phone line", "A final date to finish", "A type of work", "A meeting"], answer: 1 },
      { question: "Which word means finishing university?", options: ["Study", "Graduate", "Learn", "Pass"], answer: 1 },
      { question: "What are you DOING right now? — This uses...", options: ["Past tense", "Future tense", "Present continuous", "Modal verbs"], answer: 2 }
    ],
    challenge: "Write a short email to a colleague in English — introduce yourself and say what you do!"
  },
  {
    day: 9,
    title: "Asking Questions",
    emoji: "❓",
    color: "#7c5cfc",
    description: "Master all question words and types for any situation.",
    vocabulary: [
      { word: "Who", phonetic: "/huː/", meaning: "Asking about a person", example: "Who is your teacher?" },
      { word: "What", phonetic: "/wɒt/", meaning: "Asking about a thing", example: "What is your name?" },
      { word: "Where", phonetic: "/wɛr/", meaning: "Asking about a place", example: "Where do you live?" },
      { word: "When", phonetic: "/wɛn/", meaning: "Asking about time", example: "When is your birthday?" },
      { word: "Why", phonetic: "/waɪ/", meaning: "Asking about reason", example: "Why are you late?" },
      { word: "How", phonetic: "/haʊ/", meaning: "Asking about manner", example: "How do you spell that?" },
      { word: "Which", phonetic: "/wɪtʃ/", meaning: "Asking about choice", example: "Which book do you prefer?" },
      { word: "How many", phonetic: "/haʊ ˈmɛni/", meaning: "Asking about count", example: "How many siblings do you have?" },
      { word: "How much", phonetic: "/haʊ mʌtʃ/", meaning: "Asking about amount/price", example: "How much does it cost?" },
      { word: "How long", phonetic: "/haʊ lɒŋ/", meaning: "Asking about duration", example: "How long does it take?" }
    ],
    grammar: {
      title: "Question Formation",
      explanation: "Move the auxiliary verb before the subject to form questions.",
      rules: [
        "Statement: You are happy. → Question: Are you happy?",
        "Statement: She works here. → Question: Does she work here?",
        "Wh-questions: Where + auxiliary + subject + verb",
        "Indirect questions: Can you tell me where... ?"
      ],
      examples: ["Where do you live?", "What time does the bus leave?", "Can you tell me how to get there?"]
    },
    listeningText: "I have some questions for you. What is your full name? Where were you born? How long have you been studying English? Why do you want to learn English? Good answers! Thank you for talking with me.",
    speakingPrompt: "Ask five questions to get to know someone.",
    speakingTarget: "What do you do? Where are you from? How long have you lived here? Why do you like [topic]?",
    quiz: [
      { question: "Which word asks about a place?", options: ["Who", "What", "Where", "Why"], answer: 2 },
      { question: "How do you ask the reason for something?", options: ["What", "When", "Where", "Why"], answer: 3 },
      { question: "Correct question: 'Where ___ she work?'", options: ["do", "does", "is", "are"], answer: 1 },
      { question: "Ask about amount (uncountable): use 'how ___'", options: ["many", "much", "often", "long"], answer: 1 },
      { question: "To ask about a person, use:", options: ["What", "Which", "Who", "How"], answer: 2 }
    ],
    challenge: "Interview a friend or family member in English using all 7 question words!"
  },
  {
    day: 10,
    title: "Describing People & Places",
    emoji: "🎨",
    color: "#c084fc",
    description: "Use adjectives vividly to describe appearances and locations.",
    vocabulary: [
      { word: "Tall / Short", phonetic: "/tɔːl ʃɔːrt/", meaning: "Height description", example: "He is very tall and slim." },
      { word: "Beautiful / Handsome", phonetic: "", meaning: "Attractive appearance", example: "She is beautiful." },
      { word: "Young / Old", phonetic: "/jʌŋ oʊld/", meaning: "Age description", example: "My grandfather is very old." },
      { word: "Busy / Quiet", phonetic: "/ˈbɪzi ˈkwaɪət/", meaning: "Activity level of a place", example: "The market is very busy." },
      { word: "Modern / Ancient", phonetic: "", meaning: "Time period of a place", example: "This is an ancient temple." },
      { word: "Crowded", phonetic: "/ˈkraʊdɪd/", meaning: "Full of people", example: "The bus is very crowded." },
      { word: "Friendly", phonetic: "/ˈfrɛndli/", meaning: "Kind and warm personality", example: "The people here are friendly." },
      { word: "Famous", phonetic: "/ˈfeɪməs/", meaning: "Known by many people", example: "Dhaka is famous for its culture." },
      { word: "Noisy / Peaceful", phonetic: "", meaning: "Sound level", example: "The city is noisy but exciting." },
      { word: "Enormous / Tiny", phonetic: "", meaning: "Very big / very small", example: "The stadium is enormous!" }
    ],
    grammar: {
      title: "Order of Adjectives",
      explanation: "When using multiple adjectives, use this order: Opinion → Size → Age → Color → Origin → Material → Noun",
      rules: [
        "A beautiful big old red building",
        "Opinion first: lovely, boring, interesting",
        "Size: big, small, tall, short",
        "Age: old, new, young, ancient"
      ],
      examples: ["A lovely old Italian restaurant.", "A big black dog.", "An interesting young French artist."]
    },
    listeningText: "Let me tell you about my city. It is a large, busy city with millions of people. The old part of the city has ancient buildings and narrow streets. The new part is modern and beautiful. The people are very friendly and welcoming.",
    speakingPrompt: "Describe your city or hometown to someone who has never been there.",
    speakingTarget: "My city is [adjective]. It is known for [thing]. The people are [adjective] and the food is [adjective].",
    quiz: [
      { question: "Which adjective describes size?", options: ["Beautiful", "Huge", "Ancient", "Friendly"], answer: 1 },
      { question: "In 'a lovely small old village' — which is the opinion adjective?", options: ["Small", "Old", "Village", "Lovely"], answer: 3 },
      { question: "'Crowded' means:", options: ["Empty", "Full of people", "Very quiet", "Very old"], answer: 1 },
      { question: "The opposite of 'noisy' is:", options: ["Busy", "Crowded", "Peaceful", "Modern"], answer: 2 },
      { question: "Correct order: a ___ tall young man", options: ["Handsome", "Man handsome", "Tall handsome", "Young tall"], answer: 0 }
    ],
    challenge: "Write a detailed paragraph describing your favorite place — use at least 8 adjectives!"
  },
  {
    day: 11,
    title: "Everyday Situations",
    emoji: "🏙️",
    color: "#3b82f6",
    description: "Handle common real-life situations with confidence.",
    vocabulary: [
      { word: "Doctor's appointment", phonetic: "", meaning: "Medical visit", example: "I have a doctor's appointment today." },
      { word: "Emergency", phonetic: "/ɪˈmɜːrdʒənsi/", meaning: "Urgent situation", example: "Call 999! It's an emergency!" },
      { word: "Bank account", phonetic: "", meaning: "Financial account", example: "I need to open a bank account." },
      { word: "Fill in the form", phonetic: "", meaning: "Complete a document", example: "Please fill in this form." },
      { word: "Appointment", phonetic: "/əˈpɔɪntmənt/", meaning: "Scheduled meeting", example: "I'd like to make an appointment." },
      { word: "Wait", phonetic: "/weɪt/", meaning: "Stay until something happens", example: "Please wait a moment." },
      { word: "Complaint", phonetic: "/kəmˈpleɪnt/", meaning: "Expression of dissatisfaction", example: "I'd like to make a complaint." },
      { word: "Broken", phonetic: "/ˈbroʊkən/", meaning: "Not working", example: "The elevator is broken." },
      { word: "Replace / Refund", phonetic: "", meaning: "Swap or get money back", example: "I'd like a refund, please." },
      { word: "Working hours", phonetic: "", meaning: "Time a business is open", example: "What are your working hours?" }
    ],
    grammar: {
      title: "Past Simple — Talking About What Happened",
      explanation: "Use past simple for actions that finished at a specific time.",
      rules: [
        "Regular: work → worked, call → called",
        "Irregular: go → went, have → had, see → saw",
        "Negative: didn't + base verb",
        "Question: Did + subject + base verb?"
      ],
      examples: ["I called the doctor yesterday.", "She didn't come to work.", "Did you receive my message?"]
    },
    listeningText: "Hello, I'd like to make a complaint. My hotel room's air conditioning is broken. I called reception yesterday but nobody came. I need someone to fix it or I'd like to change rooms. I understand. I'm very sorry about that. We will send someone immediately.",
    speakingPrompt: "Make a complaint or report a problem in a formal situation.",
    speakingTarget: "I'd like to make a complaint. The [thing] is broken/not working. I called [time] but nobody helped. Can you fix it?",
    quiz: [
      { question: "Past tense of 'go' is:", options: ["Goed", "Gone", "Went", "Going"], answer: 2 },
      { question: "'I didn't call' means:", options: ["I called", "I will call", "I did not call", "I have called"], answer: 2 },
      { question: "How do you start a formal complaint?", options: ["Fix this now!", "I'd like to make a complaint.", "This is bad!", "You broke it!"], answer: 1 },
      { question: "An 'emergency' is:", options: ["A planned event", "An urgent situation", "A type of meeting", "A bank service"], answer: 1 },
      { question: "Question form of 'She went to hospital': ", options: ["Did she went?", "Did she go?", "Does she go?", "Was she go?"], answer: 1 }
    ],
    challenge: "Role-play: Pretend something is broken. Practice complaining and asking for help in English!"
  },
  {
    day: 12,
    title: "Telephone Conversations",
    emoji: "📱",
    color: "#ef4444",
    description: "Speak confidently on the phone in English.",
    vocabulary: [
      { word: "Hold on", phonetic: "/hoʊld ɒn/", meaning: "Wait a moment", example: "Hold on, I'll transfer you." },
      { word: "Speaking", phonetic: "/ˈspiːkɪŋ/", meaning: "This is the person you want", example: "'Is that John?' — 'Speaking!'" },
      { word: "Leave a message", phonetic: "", meaning: "Record information for later", example: "Can I leave a message?" },
      { word: "Call back", phonetic: "/kɔːl bæk/", meaning: "Phone again later", example: "I'll call you back in 10 minutes." },
      { word: "Wrong number", phonetic: "", meaning: "Incorrect phone number", example: "Sorry, you have the wrong number." },
      { word: "Bad connection", phonetic: "", meaning: "Poor phone signal", example: "Sorry, I have a bad connection." },
      { word: "Could you repeat that?", phonetic: "", meaning: "Ask to say again", example: "Sorry, could you repeat that?" },
      { word: "Dial", phonetic: "/daɪəl/", meaning: "Enter a phone number", example: "Dial 999 for emergencies." },
      { word: "Extension", phonetic: "/ɪkˈstɛnʃən/", meaning: "Internal phone number", example: "Press 2 for extension 305." },
      { word: "Voicemail", phonetic: "/ˈvɔɪsmeɪl/", meaning: "Recorded message service", example: "Please leave a voicemail." }
    ],
    grammar: {
      title: "Indirect Speech",
      explanation: "Reported speech — telling someone what another person said.",
      rules: [
        "Direct: 'I am busy.' → Indirect: He said he was busy.",
        "Direct: 'I will call.' → Indirect: She said she would call.",
        "Direct: 'Are you free?' → Indirect: She asked if I was free.",
        "Tenses 'shift back' in reported speech"
      ],
      examples: ["He said he couldn't come.", "She asked where I was.", "They told me to call later."]
    },
    listeningText: "Hello, this is ABC Company. How can I help you? Hello, could I speak to Ms. Johnson please? I'm afraid she's in a meeting. Can I take a message? Yes, could you tell her that David called? Of course. She'll call you back soon.",
    speakingPrompt: "Make a formal phone call to a company or office.",
    speakingTarget: "Hello, this is [name]. Could I speak to [person] please? I'm calling about [reason].",
    quiz: [
      { question: "'Hold on' means:", options: ["Goodbye", "Wait a moment", "Call back", "Leave a message"], answer: 1 },
      { question: "'Speaking' in a phone call means:", options: ["I'm busy", "I am the person you asked for", "Please wait", "Call again"], answer: 1 },
      { question: "Indirect speech: 'I am late' → She said she ___ late.", options: ["is", "was", "were", "be"], answer: 1 },
      { question: "How do you ask someone to repeat what they said?", options: ["What?!", "Repeat!", "Could you repeat that?", "Say it again!"], answer: 2 },
      { question: "'Wrong number' means:", options: ["Bad connection", "You dialled incorrectly", "The person is busy", "No answer"], answer: 1 }
    ],
    challenge: "Make a phone call in English today — call a shop, restaurant, or practice with a friend!"
  },
  {
    day: 13,
    title: "Social Communication",
    emoji: "🤝",
    color: "#10b981",
    description: "Socialize, make small talk, and communicate in social settings.",
    vocabulary: [
      { word: "Small talk", phonetic: "", meaning: "Light casual conversation", example: "We made small talk about the weather." },
      { word: "Compliment", phonetic: "/ˈkɒmplɪmənt/", meaning: "Saying something nice", example: "What a lovely dress! — Thank you!" },
      { word: "Agree / Disagree", phonetic: "", meaning: "Same / different opinion", example: "I totally agree with you!" },
      { word: "Opinion", phonetic: "/əˈpɪnjən/", meaning: "Personal view", example: "In my opinion, this is great." },
      { word: "By the way", phonetic: "", meaning: "Introducing new topic", example: "By the way, did you see the news?" },
      { word: "Actually", phonetic: "/ˈæktʃuəli/", meaning: "In reality (to correct)", example: "Actually, I think you're right." },
      { word: "Anyway", phonetic: "/ˈɛniweɪ/", meaning: "Moving on in conversation", example: "Anyway, let's get started." },
      { word: "I think / I believe", phonetic: "", meaning: "Expressing opinion softly", example: "I think we should leave early." },
      { word: "As far as I know", phonetic: "", meaning: "Based on my knowledge", example: "As far as I know, she's still here." },
      { word: "What do you think?", phonetic: "", meaning: "Asking for opinion", example: "What do you think about this idea?" }
    ],
    grammar: {
      title: "Present Perfect — Experience & News",
      explanation: "Use 'have/has + past participle' for life experiences or recent events.",
      rules: [
        "I have visited London. (life experience)",
        "Have you ever tried sushi?",
        "She has just arrived.",
        "I haven't finished yet."
      ],
      examples: ["Have you ever been abroad?", "I've never eaten octopus.", "She has already left."]
    },
    listeningText: "So, what do you think about the new restaurant downtown? Actually, I've been there twice already! Really? How was it? In my opinion, the food was amazing. Have you ever tried the pasta? Not yet, but I've heard it's incredible. You should definitely go!",
    speakingPrompt: "Have a casual social conversation, share opinions, and give compliments.",
    speakingTarget: "I think [opinion]. Have you ever [experience]? By the way, [new topic]. What do you think?",
    quiz: [
      { question: "Present perfect uses:", options: ["was/were", "have/has + past participle", "will + verb", "am/is/are + -ing"], answer: 1 },
      { question: "'Have you ever visited Paris?' asks about:", options: ["Future plans", "Life experience", "Yesterday", "A habit"], answer: 1 },
      { question: "'By the way' introduces:", options: ["An argument", "A new topic", "A complaint", "A question"], answer: 1 },
      { question: "To give your opinion softly, say:", options: ["You are wrong.", "I know that...", "I think / I believe...", "Obviously..."], answer: 2 },
      { question: "'I haven't finished yet' means:", options: ["I will never finish", "I finished already", "I have not finished", "I am finishing"], answer: 2 }
    ],
    challenge: "Start a conversation with 3 different people today using small talk phrases!"
  },
  {
    day: 14,
    title: "Real-Life Practice",
    emoji: "🌍",
    color: "#f59e0b",
    description: "Combine everything you've learned in real-world scenarios.",
    vocabulary: [
      { word: "Negotiate", phonetic: "/nɪˈɡoʊʃieɪt/", meaning: "Discuss to reach agreement", example: "Let's negotiate the price." },
      { word: "Persuade", phonetic: "/pərˈsweɪd/", meaning: "Convince someone", example: "I tried to persuade him to stay." },
      { word: "Clarify", phonetic: "/ˈklærɪfaɪ/", meaning: "Make something clearer", example: "Could you clarify that point?" },
      { word: "Summarize", phonetic: "/ˈsʌməraɪz/", meaning: "Give brief overview", example: "Can you summarize the report?" },
      { word: "Recommend", phonetic: "/ˌrɛkəˈmɛnd/", meaning: "Suggest something good", example: "I recommend the chicken curry." },
      { word: "Confirm", phonetic: "/kənˈfɜːrm/", meaning: "Make sure is correct", example: "Can you confirm the booking?" },
      { word: "Schedule", phonetic: "/ˈʃɛdjuːl/", meaning: "Plan of events/times", example: "What's on the schedule today?" },
      { word: "Priority", phonetic: "/praɪˈɒrɪti/", meaning: "Most important thing first", example: "Learning English is my priority." },
      { word: "Achieve", phonetic: "/əˈtʃiːv/", meaning: "Successfully reach a goal", example: "You can achieve anything!" },
      { word: "Fluent", phonetic: "/ˈfluːənt/", meaning: "Speak easily and naturally", example: "My goal is to be fluent." }
    ],
    grammar: {
      title: "Mixed Tenses — Real Conversation",
      explanation: "Real conversations mix all tenses naturally. Practice blending them.",
      rules: [
        "Past + Present: I studied English and now I speak it.",
        "Present + Future: I'm learning and I will improve.",
        "Perfect + Future: I have practiced and I'll be ready.",
        "Connect ideas: because, so, but, although, however"
      ],
      examples: ["I've been studying English for 14 days and tomorrow I'll take the final test!", "Although I was nervous, I spoke well.", "I started this journey because I want to travel."]
    },
    listeningText: "I can't believe you've come so far! 14 days ago, you couldn't say much in English. Now you can greet people, order food, ask for directions, make phone calls, and have real conversations! Tomorrow is your final assessment. Are you ready? I've worked hard and I'm confident. Let's do this!",
    speakingPrompt: "Tell someone your English learning story — where you started and how you've improved.",
    speakingTarget: "Two weeks ago, I couldn't speak English well. Now I can [skills]. My goal is to become fluent. Tomorrow is my final assessment!",
    quiz: [
      { question: "To 'negotiate' means to:", options: ["Argue", "Give up", "Discuss to reach agreement", "Complain"], answer: 2 },
      { question: "'I've been studying for 14 days' — this is:", options: ["Past simple", "Present perfect continuous", "Future", "Past continuous"], answer: 1 },
      { question: "To be 'fluent' means to:", options: ["Know some words", "Make many mistakes", "Speak easily and naturally", "Only read English"], answer: 2 },
      { question: "'Although I was nervous, I spoke well' connects:", options: ["Two similar ideas", "A contrast", "A future plan", "A complaint"], answer: 1 },
      { question: "What does 'summarize' mean?", options: ["Talk for a long time", "Give a brief overview", "Ask a question", "Make a complaint"], answer: 1 }
    ],
    challenge: "Have a full 5-minute conversation in English about any topic — no switching languages!"
  },
  {
    day: 15,
    title: "Final Speaking Assessment",
    emoji: "🏆",
    color: "#f59e0b",
    description: "Showcase everything you've learned! Complete your final English assessment.",
    vocabulary: [
      { word: "Assessment", phonetic: "/əˈsɛsmənt/", meaning: "Evaluation of skills", example: "Today is my final assessment." },
      { word: "Fluency", phonetic: "/ˈfluːənsi/", meaning: "Natural, smooth speech", example: "I've improved my fluency!" },
      { word: "Confidence", phonetic: "/ˈkɒnfɪdəns/", meaning: "Belief in your ability", example: "Speak with confidence!" },
      { word: "Achievement", phonetic: "/əˈtʃiːvmənt/", meaning: "Success after hard work", example: "Completing this course is a great achievement!" },
      { word: "Progress", phonetic: "/ˈprəʊɡrɛs/", meaning: "Moving forward/improving", example: "You've made amazing progress!" },
      { word: "Challenge", phonetic: "/ˈtʃælɪndʒ/", meaning: "Something difficult to overcome", example: "I overcame every challenge." },
      { word: "Goal", phonetic: "/ɡoʊl/", meaning: "Target you want to reach", example: "My goal was to learn English." },
      { word: "Communicate", phonetic: "/kəˈmjuːnɪkeɪt/", meaning: "Share information/ideas", example: "Now I can communicate in English!" },
      { word: "Celebrate", phonetic: "/ˈsɛlɪbreɪt/", meaning: "Mark a special occasion", example: "Let's celebrate your success!" },
      { word: "Future", phonetic: "/ˈfjuːtʃər/", meaning: "Time ahead", example: "Your English future looks bright!" }
    ],
    grammar: {
      title: "Review — All Tenses & Structures",
      explanation: "Show mastery of all tenses and grammar you've learned in 15 days.",
      rules: [
        "Present Simple, Continuous & Perfect",
        "Past Simple & Continuous",
        "Future with will/going to",
        "Modals, comparatives, questions"
      ],
      examples: ["I have learned so much!", "I was nervous but now I'm confident.", "I will keep practicing every day."]
    },
    listeningText: "Congratulations on reaching Day 15! You have worked incredibly hard over the past two weeks. Today you will demonstrate your English speaking skills in a full assessment. Remember everything you've learned: greetings, conversations, questions, descriptions, and more. Take a deep breath. You've got this!",
    speakingPrompt: "Complete the final assessment: Introduce yourself, describe your life, tell your English learning story, and talk about your future goals.",
    speakingTarget: "Hello! My name is [name]. I am from [place]. I have been learning English for 15 days. Before, I couldn't speak English well. Now I can [skills]. My goal is to [future plan]. Thank you!",
    quiz: [
      { question: "Which shows Present Perfect?", options: ["I learn every day", "I learned yesterday", "I have learned a lot", "I will learn more"], answer: 2 },
      { question: "Which is a correct comparative sentence?", options: ["I am more better", "She speaks more fluently than me", "He is most tall", "They is bigger"], answer: 1 },
      { question: "Correct question form:", options: ["Where you live?", "Where do you live?", "Where does you live?", "Where are you live?"], answer: 1 },
      { question: "Which sentence uses FUTURE tense?", options: ["I studied English", "I study English", "I am studying English", "I will study English"], answer: 3 },
      { question: "Which sentence is grammatically correct?", options: ["She don't like it", "They doesn't know", "He doesn't speak French", "I doesn't want"], answer: 2 }
    ],
    challenge: "Record a 2-minute video of yourself speaking in English. Share it with someone you trust — you've earned it! 🎉"
  }
];

export const BADGES = [
  { id: "first_step", name: "First Step", emoji: "👶", description: "Complete Day 1", condition: (progress) => progress.completedDays.includes(1) },
  { id: "week_one", name: "Week Warrior", emoji: "⚔️", description: "Complete 7 days", condition: (progress) => progress.completedDays.length >= 7 },
  { id: "halfway", name: "Halfway Hero", emoji: "🦸", description: "Complete Day 8", condition: (progress) => progress.completedDays.includes(8) },
  { id: "streak_3", name: "3-Day Streak", emoji: "🔥", description: "3 days in a row", condition: (progress) => progress.streak >= 3 },
  { id: "streak_7", name: "Week Streak", emoji: "🌟", description: "7 days in a row", condition: (progress) => progress.streak >= 7 },
  { id: "perfect_quiz", name: "Quiz Master", emoji: "🎯", description: "100% on a quiz", condition: (progress) => progress.perfectQuizzes > 0 },
  { id: "voice_star", name: "Voice Star", emoji: "🎤", description: "Score 90%+ speaking", condition: (progress) => progress.speakingScores.some(s => s >= 90) },
  { id: "graduate", name: "Graduate", emoji: "🎓", description: "Complete all 15 days", condition: (progress) => progress.completedDays.length >= 15 }
];

export const MOTIVATIONAL_MESSAGES = [
  "Amazing work! Every word you speak brings you closer to fluency! 🌟",
  "You're incredible! Keep going — the world is waiting to hear your English! 🌍",
  "Day by day, step by step — you're becoming an English speaker! 💪",
  "Wow, look at you go! Your English is getting stronger every day! 🚀",
  "Fantastic progress! Fluency is closer than you think! ✨",
  "You did it! Your hard work is paying off. Don't stop now! 🎯",
  "Brilliant! You should be so proud of yourself! 🏆",
  "Keep shining! Every lesson makes you more confident! ⭐"
];
