import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import './Onboarding.css';

export default function Onboarding() {
  const { dispatch } = useApp();
  const [step, setStep] = useState(0); // 0=welcome, 1=name, 2=goal
  const [name, setName] = useState('');
  const [goal, setGoal] = useState('');

  const goals = [
    { id: 'travel', emoji: '✈️', label: 'Travel & Tourism' },
    { id: 'work', emoji: '💼', label: 'Work & Career' },
    { id: 'study', emoji: '📚', label: 'Study Abroad' },
    { id: 'daily', emoji: '💬', label: 'Daily Conversations' },
  ];

  const handleStart = () => {
    if (!name.trim()) return;
    dispatch({
      type: 'SET_USER',
      payload: { name: name.trim(), goal, joinedAt: new Date().toISOString() }
    });
  };

  return (
    <div className="onboarding">
      {/* Background orbs */}
      <div className="orb orb-1" />
      <div className="orb orb-2" />
      <div className="orb orb-3" />

      {step === 0 && (
        <div className="ob-screen fade-up">
          <div className="ob-emoji-big">🇬🇧</div>
          <h1 className="ob-title">English in<br /><span className="gradient-text">15 Days</span></h1>
          <p className="ob-subtitle">
            From zero to speaking — practical English skills
            you can use in real life, every single day.
          </p>
          <div className="ob-features">
            <div className="ob-feature"><span>🎤</span><p>Voice-based learning</p></div>
            <div className="ob-feature"><span>🤖</span><p>AI speaking coach</p></div>
            <div className="ob-feature"><span>🏆</span><p>Gamified progress</p></div>
          </div>
          <button className="btn-primary ob-cta" onClick={() => setStep(1)}>
            Start Learning Free →
          </button>
          <p className="ob-note">No account needed · Works offline</p>
        </div>
      )}

      {step === 1 && (
        <div className="ob-screen fade-up">
          <button className="ob-back" onClick={() => setStep(0)}>← Back</button>
          <div className="ob-emoji-big">👋</div>
          <h2 className="ob-title-sm">What's your name?</h2>
          <p className="ob-subtitle-sm">I'll personalize your lessons just for you.</p>
          <input
            className="ob-input"
            type="text"
            placeholder="Enter your name..."
            value={name}
            onChange={e => setName(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && name.trim() && setStep(2)}
            autoFocus
          />
          <button
            className="btn-primary ob-cta"
            onClick={() => name.trim() && setStep(2)}
            disabled={!name.trim()}
          >
            Continue →
          </button>
        </div>
      )}

      {step === 2 && (
        <div className="ob-screen fade-up">
          <button className="ob-back" onClick={() => setStep(1)}>← Back</button>
          <div className="ob-emoji-big">🎯</div>
          <h2 className="ob-title-sm">Hi {name}! What's your goal?</h2>
          <p className="ob-subtitle-sm">This helps me focus on the right topics for you.</p>
          <div className="ob-goals">
            {goals.map(g => (
              <button
                key={g.id}
                className={`ob-goal-btn ${goal === g.id ? 'selected' : ''}`}
                onClick={() => setGoal(g.id)}
              >
                <span className="ob-goal-emoji">{g.emoji}</span>
                <span>{g.label}</span>
              </button>
            ))}
          </div>
          <button className="btn-primary ob-cta" onClick={handleStart}>
            Begin 15-Day Journey 🚀
          </button>
        </div>
      )}
    </div>
  );
}
