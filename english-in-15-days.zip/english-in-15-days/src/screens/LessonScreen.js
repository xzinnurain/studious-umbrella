import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { DAYS_DATA } from '../data/lessons';
import VocabularyStep from '../components/lesson/VocabularyStep';
import GrammarStep from '../components/lesson/GrammarStep';
import ListeningStep from '../components/lesson/ListeningStep';
import SpeakingStep from '../components/lesson/SpeakingStep';
import QuizStep from '../components/lesson/QuizStep';
import ChallengeStep from '../components/lesson/ChallengeStep';
import './Lesson.css';

const STEPS = ['vocabulary', 'grammar', 'listening', 'speaking', 'quiz', 'challenge'];
const STEP_LABELS = {
  vocabulary: { label: 'Vocabulary', emoji: '📖' },
  grammar: { label: 'Grammar', emoji: '✏️' },
  listening: { label: 'Listening', emoji: '👂' },
  speaking: { label: 'Speaking', emoji: '🎤' },
  quiz: { label: 'Quiz', emoji: '❓' },
  challenge: { label: 'Challenge', emoji: '⚡' }
};

export default function LessonScreen() {
  const { state, dispatch } = useApp();
  const { currentLesson, lessonStep, lessonProgress } = state;
  const dayData = DAYS_DATA[currentLesson - 1];
  const stepIdx = STEPS.indexOf(lessonStep);

  const goToStep = (step) => dispatch({ type: 'SET_LESSON_STEP', payload: step });
  const completeStep = (step) => dispatch({ type: 'COMPLETE_STEP', payload: step });

  const goBack = () => {
    if (stepIdx === 0) dispatch({ type: 'SET_SCREEN', payload: 'dashboard' });
    else goToStep(STEPS[stepIdx - 1]);
  };

  const handleStepComplete = (step) => {
    completeStep(step);
    if (step === 'challenge') {
      dispatch({ type: 'COMPLETE_DAY', payload: currentLesson });
    } else {
      const nextIdx = STEPS.indexOf(step) + 1;
      if (nextIdx < STEPS.length) goToStep(STEPS[nextIdx]);
    }
  };

  const stepsCompleted = STEPS.filter(s => lessonProgress[s]).length;
  const progressPct = Math.round((stepsCompleted / STEPS.length) * 100);

  return (
    <div className="lesson-screen">
      {/* Lesson Header */}
      <header className="lesson-header">
        <button className="lesson-back-btn" onClick={goBack}>←</button>
        <div className="lesson-header-center">
          <p className="lesson-day-label">Day {currentLesson}/15</p>
          <h2 className="lesson-title">{dayData.emoji} {dayData.title}</h2>
        </div>
        <div className="lesson-xp-badge">⚡ +100</div>
      </header>

      {/* Progress Steps */}
      <div className="lesson-steps-nav">
        {STEPS.map((step, idx) => (
          <div
            key={step}
            className={`step-dot ${lessonProgress[step] ? 'done' : ''} ${lessonStep === step ? 'active' : ''} ${idx > stepIdx && !lessonProgress[step] ? 'upcoming' : ''}`}
            title={STEP_LABELS[step].label}
          >
            {lessonProgress[step] ? '✓' : STEP_LABELS[step].emoji}
          </div>
        ))}
      </div>

      {/* Lesson progress bar */}
      <div className="lesson-progress-bar">
        <div className="lesson-progress-fill" style={{ width: `${progressPct}%`, background: dayData.color }} />
      </div>

      {/* Current Step Content */}
      <div className="lesson-body">
        <div className="lesson-step-header">
          <span className="step-emoji">{STEP_LABELS[lessonStep].emoji}</span>
          <h3>{STEP_LABELS[lessonStep].label}</h3>
        </div>

        {lessonStep === 'vocabulary' && (
          <VocabularyStep
            words={dayData.vocabulary}
            onComplete={() => handleStepComplete('vocabulary')}
          />
        )}
        {lessonStep === 'grammar' && (
          <GrammarStep
            grammar={dayData.grammar}
            onComplete={() => handleStepComplete('grammar')}
          />
        )}
        {lessonStep === 'listening' && (
          <ListeningStep
            text={dayData.listeningText}
            onComplete={() => handleStepComplete('listening')}
          />
        )}
        {lessonStep === 'speaking' && (
          <SpeakingStep
            prompt={dayData.speakingPrompt}
            target={dayData.speakingTarget}
            topic={dayData.title}
            dayNum={currentLesson}
            onComplete={() => handleStepComplete('speaking')}
          />
        )}
        {lessonStep === 'quiz' && (
          <QuizStep
            questions={dayData.quiz}
            onComplete={() => handleStepComplete('quiz')}
          />
        )}
        {lessonStep === 'challenge' && (
          <ChallengeStep
            challenge={dayData.challenge}
            dayNum={currentLesson}
            onComplete={() => handleStepComplete('challenge')}
          />
        )}
      </div>
    </div>
  );
}
