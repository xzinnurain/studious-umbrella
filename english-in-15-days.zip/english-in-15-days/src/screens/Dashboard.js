import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { DAYS_DATA, BADGES, MOTIVATIONAL_MESSAGES } from '../data/lessons';
import './Dashboard.css';

export default function Dashboard() {
  const { state, dispatch } = useApp();
  const { user, progress, theme } = state;
  const [activeTab, setActiveTab] = useState('home');

  const completionPct = Math.round((progress.completedDays.length / 15) * 100);
  const currentDayData = DAYS_DATA[progress.currentDay - 1];
  const motivational = MOTIVATIONAL_MESSAGES[progress.completedDays.length % MOTIVATIONAL_MESSAGES.length];

  const toggleTheme = () => {
    dispatch({ type: 'SET_THEME', payload: theme === 'dark' ? 'light' : 'dark' });
  };

  const startLesson = (day) => {
    if (day > progress.currentDay) return; // locked
    dispatch({ type: 'START_LESSON', payload: day });
  };

  return (
    <div className="dashboard">
      {/* Header */}
      <header className="dash-header">
        <div className="dash-header-left">
          <div className="dash-avatar">{user?.name?.[0]?.toUpperCase()}</div>
          <div>
            <p className="dash-greeting">Good day, {user?.name}! 👋</p>
            <p className="dash-subgreeting">Keep going — you're doing great!</p>
          </div>
        </div>
        <div className="dash-header-right">
          <button className="theme-btn" onClick={toggleTheme}>
            {theme === 'dark' ? '☀️' : '🌙'}
          </button>
        </div>
      </header>

      {/* Tabs */}
      <div className="dash-tabs">
        {['home', 'lessons', 'badges', 'coach'].map(t => (
          <button
            key={t}
            className={`dash-tab ${activeTab === t ? 'active' : ''}`}
            onClick={() => setActiveTab(t)}
          >
            {t === 'home' && '🏠'}
            {t === 'lessons' && '📚'}
            {t === 'badges' && '🏆'}
            {t === 'coach' && '🤖'}
            <span>{t.charAt(0).toUpperCase() + t.slice(1)}</span>
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="dash-content">

        {/* HOME TAB */}
        {activeTab === 'home' && (
          <div className="tab-home">
            {/* XP & Streak Bar */}
            <div className="stats-row">
              <div className="stat-chip xp">
                <span>⚡</span>
                <div>
                  <p className="stat-val">{progress.xp}</p>
                  <p className="stat-lbl">XP Points</p>
                </div>
              </div>
              <div className="stat-chip streak">
                <span>🔥</span>
                <div>
                  <p className="stat-val">{progress.streak}</p>
                  <p className="stat-lbl">Day Streak</p>
                </div>
              </div>
              <div className="stat-chip days">
                <span>📅</span>
                <div>
                  <p className="stat-val">{progress.completedDays.length}/15</p>
                  <p className="stat-lbl">Completed</p>
                </div>
              </div>
            </div>

            {/* Overall Progress */}
            <div className="progress-card glass-card">
              <div className="progress-card-header">
                <span>Overall Progress</span>
                <span className="progress-pct">{completionPct}%</span>
              </div>
              <div className="progress-bar-track">
                <div className="progress-bar-fill" style={{ width: `${completionPct}%` }} />
              </div>
              <p className="progress-label">Day {progress.currentDay} of 15</p>
            </div>

            {/* Today's Lesson */}
            {progress.completedDays.length < 15 ? (
              <div className="today-card" style={{ '--day-color': currentDayData.color }}>
                <div className="today-top">
                  <div>
                    <p className="today-label">TODAY'S LESSON</p>
                    <h3 className="today-title">{currentDayData.emoji} {currentDayData.title}</h3>
                    <p className="today-desc">{currentDayData.description}</p>
                  </div>
                </div>
                <div className="today-meta">
                  <span className="today-day-badge">Day {progress.currentDay}/15</span>
                  <span>🎯 6 Activities</span>
                  <span>⚡ +100 XP</span>
                </div>
                <button
                  className="today-btn"
                  onClick={() => startLesson(progress.currentDay)}
                >
                  {progress.completedDays.includes(progress.currentDay)
                    ? '🔁 Review Lesson'
                    : '▶ Start Lesson'
                  }
                </button>
              </div>
            ) : (
              <div className="complete-card glass-card">
                <div className="complete-emoji">🎓</div>
                <h3>You've completed the course!</h3>
                <p>Amazing achievement — you're now an English speaker!</p>
                <button className="btn-primary" onClick={() => setActiveTab('badges')}>
                  See Your Badges
                </button>
              </div>
            )}

            {/* Motivational message */}
            {progress.completedDays.length > 0 && (
              <div className="motivation-card glass-card">
                <p>💬 {motivational}</p>
              </div>
            )}
          </div>
        )}

        {/* LESSONS TAB */}
        {activeTab === 'lessons' && (
          <div className="tab-lessons">
            <h3 className="section-title">All 15 Days</h3>
            <div className="days-grid">
              {DAYS_DATA.map((day, idx) => {
                const dayNum = idx + 1;
                const isCompleted = progress.completedDays.includes(dayNum);
                const isCurrent = dayNum === progress.currentDay;
                const isLocked = dayNum > progress.currentDay;

                return (
                  <button
                    key={dayNum}
                    className={`day-card ${isCompleted ? 'completed' : ''} ${isCurrent ? 'current' : ''} ${isLocked ? 'locked' : ''}`}
                    style={{ '--day-color': day.color }}
                    onClick={() => !isLocked && startLesson(dayNum)}
                    disabled={isLocked}
                  >
                    <div className="day-card-num">
                      {isCompleted ? '✓' : isLocked ? '🔒' : dayNum}
                    </div>
                    <div className="day-card-emoji">{day.emoji}</div>
                    <p className="day-card-title">{day.title}</p>
                    {isCurrent && !isCompleted && (
                      <span className="day-current-badge">TODAY</span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* BADGES TAB */}
        {activeTab === 'badges' && (
          <div className="tab-badges">
            <h3 className="section-title">Achievements</h3>
            <p className="section-sub">{progress.badges.length}/{BADGES.length} earned</p>
            <div className="badges-grid">
              {BADGES.map(badge => {
                const earned = progress.badges.includes(badge.id);
                return (
                  <div key={badge.id} className={`badge-item ${earned ? 'earned' : 'locked'}`}>
                    <div className="badge-emoji">{earned ? badge.emoji : '🔒'}</div>
                    <p className="badge-name">{badge.name}</p>
                    <p className="badge-desc">{badge.description}</p>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* COACH TAB */}
        {activeTab === 'coach' && (
          <div className="tab-coach">
            <h3 className="section-title">AI Speaking Coach</h3>
            <p className="section-sub">Practice conversations with your AI coach</p>
            <div className="coach-stats">
              <div className="coach-stat">
                <p className="cs-val">{progress.speakingScores.length}</p>
                <p className="cs-lbl">Speaking Sessions</p>
              </div>
              <div className="coach-stat">
                <p className="cs-val">
                  {progress.speakingScores.length > 0
                    ? Math.round(progress.speakingScores.reduce((a, b) => a + b, 0) / progress.speakingScores.length)
                    : 0}%
                </p>
                <p className="cs-lbl">Avg Score</p>
              </div>
              <div className="coach-stat">
                <p className="cs-val">{progress.perfectQuizzes}</p>
                <p className="cs-lbl">Perfect Quizzes</p>
              </div>
            </div>
            <div className="coach-card glass-card">
              <div className="coach-avatar">🤖</div>
              <h4>Your AI Speaking Coach</h4>
              <p>Practice today's lesson to activate the AI Coach and get personalized feedback on your pronunciation and grammar.</p>
              <button
                className="btn-primary"
                onClick={() => startLesson(progress.currentDay)}
              >
                Practice with AI Coach 🎤
              </button>
            </div>
            {/* Score history */}
            {progress.speakingScores.length > 0 && (
              <div className="score-history">
                <h4>Speaking Score History</h4>
                <div className="score-bars">
                  {progress.speakingScores.slice(-10).map((score, i) => (
                    <div key={i} className="score-bar-wrap">
                      <div className="score-bar" style={{ height: `${score}%` }} />
                      <span>{score}%</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
