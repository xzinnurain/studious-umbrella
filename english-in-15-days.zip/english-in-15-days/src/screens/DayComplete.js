import React, { useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { DAYS_DATA, BADGES, MOTIVATIONAL_MESSAGES } from '../data/lessons';
import { generateFinalReport } from '../services/aiCoach';
import './DayComplete.css';

export default function DayComplete() {
  const { state, dispatch } = useApp();
  const { progress, user, quizScore, speakingScore } = state;
  const completedDay = progress.completedDays[progress.completedDays.length - 1];
  const dayData = completedDay ? DAYS_DATA[completedDay - 1] : DAYS_DATA[0];
  const isFinished = progress.completedDays.length >= 15;

  const motivational = MOTIVATIONAL_MESSAGES[
    Math.floor(Math.random() * MOTIVATIONAL_MESSAGES.length)
  ];

  // New badges earned
  const newBadges = BADGES.filter(b =>
    progress.badges.includes(b.id) &&
    b.condition({ ...progress, completedDays: progress.completedDays.slice(0, -1) }) === false
  );

  const earnedBadges = BADGES.filter(b => {
    const prevProgress = { ...progress, completedDays: progress.completedDays.slice(0, -1) };
    return progress.badges.includes(b.id) && !b.condition(prevProgress);
  });

  const handleContinue = () => {
    dispatch({ type: 'HIDE_CONFETTI' });
    dispatch({ type: 'SET_SCREEN', payload: 'dashboard' });
  };

  return (
    <div className="day-complete">
      {/* Animated BG */}
      <div className="dc-bg">
        <div className="dc-orb dc-orb-1" />
        <div className="dc-orb dc-orb-2" />
      </div>

      <div className="dc-content">
        {/* Trophy */}
        <div className="dc-trophy">{isFinished ? '🎓' : dayData.emoji}</div>

        <h1 className="dc-title">
          {isFinished ? 'Course Complete!' : `Day ${completedDay} Complete!`}
        </h1>

        <p className="dc-subtitle">
          {isFinished
            ? `Incredible, ${user?.name}! You've completed all 15 days! You're an English speaker now!`
            : motivational
          }
        </p>

        {/* Stats */}
        <div className="dc-stats">
          <div className="dc-stat">
            <span className="dc-stat-icon">⚡</span>
            <span className="dc-stat-val">+{100 + (quizScore || 0)}</span>
            <span className="dc-stat-lbl">XP Earned</span>
          </div>
          <div className="dc-stat">
            <span className="dc-stat-icon">🔥</span>
            <span className="dc-stat-val">{progress.streak}</span>
            <span className="dc-stat-lbl">Day Streak</span>
          </div>
          {quizScore !== null && (
            <div className="dc-stat">
              <span className="dc-stat-icon">❓</span>
              <span className="dc-stat-val">{quizScore}%</span>
              <span className="dc-stat-lbl">Quiz Score</span>
            </div>
          )}
          {speakingScore !== null && (
            <div className="dc-stat">
              <span className="dc-stat-icon">🎤</span>
              <span className="dc-stat-val">{speakingScore}%</span>
              <span className="dc-stat-lbl">Speaking</span>
            </div>
          )}
        </div>

        {/* Progress toward 15 */}
        <div className="dc-progress-row">
          <span className="dc-progress-label">Course Progress</span>
          <span className="dc-progress-pct">{Math.round((progress.completedDays.length / 15) * 100)}%</span>
        </div>
        <div className="dc-progress-track">
          <div
            className="dc-progress-fill"
            style={{ width: `${(progress.completedDays.length / 15) * 100}%` }}
          />
        </div>
        <p className="dc-progress-days">{progress.completedDays.length} / 15 days complete</p>

        {/* Day dots */}
        <div className="dc-day-dots">
          {Array.from({ length: 15 }, (_, i) => (
            <div
              key={i}
              className={`dc-day-dot ${progress.completedDays.includes(i + 1) ? 'done' : ''} ${i + 1 === completedDay ? 'just-done' : ''}`}
            />
          ))}
        </div>

        {/* New Badges */}
        {earnedBadges.length > 0 && (
          <div className="dc-badges">
            <p className="dc-badges-title">🏆 New Badge{earnedBadges.length > 1 ? 's' : ''} Earned!</p>
            <div className="dc-badges-row">
              {earnedBadges.map(b => (
                <div key={b.id} className="dc-badge">
                  <span className="dc-badge-emoji">{b.emoji}</span>
                  <span className="dc-badge-name">{b.name}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Next day preview */}
        {!isFinished && progress.currentDay <= 15 && (
          <div className="dc-next-preview">
            <p className="dc-next-label">Coming up — Day {progress.currentDay}</p>
            <p className="dc-next-title">
              {DAYS_DATA[progress.currentDay - 1]?.emoji} {DAYS_DATA[progress.currentDay - 1]?.title}
            </p>
          </div>
        )}

        <button className="dc-continue-btn" onClick={handleContinue}>
          {isFinished ? '🎓 See Final Report' : `Continue to Day ${progress.currentDay} →`}
        </button>

        <p className="dc-total-xp">Total XP: {progress.xp} ⚡</p>
      </div>
    </div>
  );
}
