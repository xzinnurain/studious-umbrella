// GrammarStep.js
import React, { useState } from 'react';
import { useTTS } from '../../hooks/useSpeech';
import './Steps.css';

export function GrammarStep({ grammar, onComplete }) {
  const [understood, setUnderstood] = useState(false);
  const { speak } = useTTS();

  return (
    <div className="grammar-step">
      <div className="grammar-card glass-card">
        <h3 className="grammar-title">{grammar.title}</h3>
        <p className="grammar-explanation">{grammar.explanation}</p>

        <div className="grammar-rules">
          <p className="grammar-section-label">📏 Rules</p>
          {grammar.rules.map((rule, i) => (
            <div key={i} className="grammar-rule">
              <span className="rule-num">{i + 1}</span>
              <span>{rule}</span>
            </div>
          ))}
        </div>

        <div className="grammar-examples">
          <p className="grammar-section-label">✨ Examples</p>
          {grammar.examples.map((ex, i) => (
            <div key={i} className="grammar-example-row">
              <p className="grammar-example-text">{ex}</p>
              <button className="speak-btn-icon" onClick={() => speak(ex)}>🔊</button>
            </div>
          ))}
        </div>
      </div>

      <div className="understood-check">
        <button
          className={`understood-btn ${understood ? 'checked' : ''}`}
          onClick={() => setUnderstood(!understood)}
        >
          {understood ? '✓' : '○'} I understand this grammar rule
        </button>
      </div>

      <button className="step-complete-btn" onClick={onComplete} disabled={!understood}>
        Continue to Listening →
      </button>
    </div>
  );
}

export default GrammarStep;
