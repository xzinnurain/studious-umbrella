import React, { useState } from 'react';
import { useTTS } from '../../hooks/useSpeech';
import './Steps.css';

export default function VocabularyStep({ words, onComplete }) {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [seen, setSeen] = useState(new Set());
  const { speak, speaking } = useTTS();

  const word = words[currentIdx];
  const allSeen = seen.size >= words.length;

  const handleNext = () => {
    setSeen(prev => new Set([...prev, currentIdx]));
    setFlipped(false);
    setTimeout(() => {
      if (currentIdx < words.length - 1) setCurrentIdx(currentIdx + 1);
    }, 150);
  };

  const handlePrev = () => {
    setFlipped(false);
    setTimeout(() => {
      if (currentIdx > 0) setCurrentIdx(currentIdx - 1);
    }, 150);
  };

  const handleSpeak = () => speak(word.word);

  return (
    <div className="vocab-step">
      <p className="step-counter">{currentIdx + 1} / {words.length} words</p>

      {/* Flashcard */}
      <div className={`vocab-card ${flipped ? 'flipped' : ''}`} onClick={() => setFlipped(!flipped)}>
        <div className="vocab-card-front">
          <p className="vocab-hint">Tap to reveal meaning</p>
          <h2 className="vocab-word">{word.word}</h2>
          {word.phonetic && <p className="vocab-phonetic">{word.phonetic}</p>}
          <button
            className="speak-btn"
            onClick={(e) => { e.stopPropagation(); handleSpeak(); }}
            disabled={speaking}
          >
            {speaking ? '🔊' : '▶ Listen'}
          </button>
        </div>
        <div className="vocab-card-back">
          <p className="vocab-meaning-label">Meaning</p>
          <p className="vocab-meaning">{word.meaning}</p>
          <div className="vocab-divider" />
          <p className="vocab-example-label">Example</p>
          <p className="vocab-example">"{word.example}"</p>
          <button
            className="speak-btn speak-btn-sm"
            onClick={(e) => { e.stopPropagation(); speak(word.example); }}
          >
            ▶ Hear example
          </button>
        </div>
      </div>

      {/* Word list progress dots */}
      <div className="vocab-dots">
        {words.map((_, i) => (
          <div
            key={i}
            className={`vocab-dot ${i === currentIdx ? 'active' : ''} ${seen.has(i) ? 'seen' : ''}`}
            onClick={() => { setFlipped(false); setCurrentIdx(i); }}
          />
        ))}
      </div>

      {/* Navigation */}
      <div className="vocab-nav">
        <button className="vocab-nav-btn" onClick={handlePrev} disabled={currentIdx === 0}>← Prev</button>
        {currentIdx < words.length - 1 ? (
          <button className="vocab-nav-btn primary" onClick={handleNext}>Next →</button>
        ) : (
          <button className="vocab-nav-btn primary" onClick={() => setSeen(prev => new Set([...prev, currentIdx]))}>
            Mark Done ✓
          </button>
        )}
      </div>

      {/* All words list */}
      <div className="vocab-all">
        <p className="vocab-all-title">All {words.length} words:</p>
        <div className="vocab-chips">
          {words.map((w, i) => (
            <button
              key={i}
              className={`vocab-chip ${seen.has(i) ? 'seen' : ''}`}
              onClick={() => { setCurrentIdx(i); setFlipped(false); speak(w.word); }}
            >
              {w.word}
            </button>
          ))}
        </div>
      </div>

      <button
        className="step-complete-btn"
        onClick={onComplete}
        disabled={seen.size < Math.min(5, words.length)}
      >
        {allSeen ? '✓ Complete Vocabulary' : `Review at least ${Math.min(5, words.length)} words first`}
      </button>
    </div>
  );
}
