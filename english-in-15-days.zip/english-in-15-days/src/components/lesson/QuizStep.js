import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import './Steps.css';

export default function QuizStep({ questions, onComplete }) {
  const { dispatch } = useApp();
  const [currentQ, setCurrentQ] = useState(0);
  const [selected, setSelected] = useState(null);
  const [answers, setAnswers] = useState([]);
  const [showResult, setShowResult] = useState(false);
  const [finalScore, setFinalScore] = useState(null);

  const q = questions[currentQ];

  const handleSelect = (optionIdx) => {
    if (selected !== null) return;
    setSelected(optionIdx);
  };

  const handleNext = () => {
    const newAnswers = [...answers, { question: currentQ, selected, correct: q.answer }];
    setAnswers(newAnswers);

    if (currentQ < questions.length - 1) {
      setTimeout(() => {
        setCurrentQ(currentQ + 1);
        setSelected(null);
      }, 800);
    } else {
      // Calculate score
      const correctCount = newAnswers.filter(a => a.selected === a.correct).length;
      const score = Math.round((correctCount / questions.length) * 100);
      setFinalScore(score);
      dispatch({ type: 'SET_QUIZ_SCORE', payload: score });
      setTimeout(() => setShowResult(true), 800);
    }
  };

  const passed = finalScore >= 70;

  if (showResult) {
    return (
      <div className="quiz-result">
        <div className={`quiz-result-circle ${passed ? 'passed' : 'failed'}`}>
          <span className="quiz-result-emoji">{passed ? '🎉' : '😅'}</span>
          <span className="quiz-result-score">{finalScore}%</span>
          <span className="quiz-result-label">{passed ? 'Passed!' : 'Not quite...'}</span>
        </div>

        <div className="quiz-answers-review">
          {questions.map((q, i) => {
            const ans = answers[i];
            const isCorrect = ans?.selected === ans?.correct;
            return (
              <div key={i} className={`quiz-review-item ${isCorrect ? 'correct' : 'wrong'}`}>
                <span className="quiz-review-icon">{isCorrect ? '✓' : '✗'}</span>
                <div>
                  <p className="quiz-review-q">{q.question}</p>
                  {!isCorrect && (
                    <p className="quiz-review-correct">Correct: {q.options[q.answer]}</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {passed ? (
          <button className="step-complete-btn" onClick={onComplete}>
            ✓ Complete Quiz — Move to Challenge!
          </button>
        ) : (
          <div>
            <p className="quiz-retry-notice">You need 70% to pass. Try again!</p>
            <button className="step-complete-btn" onClick={() => {
              setCurrentQ(0); setSelected(null); setAnswers([]);
              setShowResult(false); setFinalScore(null);
            }}>
              🔁 Retry Quiz
            </button>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="quiz-step">
      <div className="quiz-progress-info">
        <span>Question {currentQ + 1} of {questions.length}</span>
        <span>{answers.filter(a => a.selected === a.correct).length} correct so far</span>
      </div>

      <div className="quiz-progress-bar">
        <div className="quiz-progress-fill" style={{ width: `${((currentQ) / questions.length) * 100}%` }} />
      </div>

      <div className="quiz-question-card glass-card">
        <p className="quiz-question-text">{q.question}</p>
      </div>

      <div className="quiz-options">
        {q.options.map((opt, i) => {
          let cls = 'quiz-option';
          if (selected !== null) {
            if (i === q.answer) cls += ' correct';
            else if (i === selected && selected !== q.answer) cls += ' wrong';
          }
          if (selected === i) cls += ' selected';

          return (
            <button key={i} className={cls} onClick={() => handleSelect(i)}>
              <span className="quiz-option-letter">{String.fromCharCode(65 + i)}</span>
              <span>{opt}</span>
            </button>
          );
        })}
      </div>

      {selected !== null && (
        <div className={`quiz-feedback ${selected === q.answer ? 'correct-fb' : 'wrong-fb'}`}>
          {selected === q.answer
            ? '✓ Correct! Great job!'
            : `✗ The correct answer is: "${q.options[q.answer]}"`
          }
        </div>
      )}

      <button
        className="step-complete-btn"
        onClick={handleNext}
        disabled={selected === null}
      >
        {currentQ < questions.length - 1 ? 'Next Question →' : 'See Results'}
      </button>
    </div>
  );
}
