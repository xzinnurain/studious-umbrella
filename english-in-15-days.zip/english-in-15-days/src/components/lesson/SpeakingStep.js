import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { useSTT, useTTS, scorePronunciation } from '../../hooks/useSpeech';
import { getAIFeedback } from '../../services/aiCoach';
import './Steps.css';

export default function SpeakingStep({ prompt, target, topic, dayNum, onComplete }) {
  const { dispatch } = useApp();
  const { listening, transcript, error, startListening, stopListening } = useSTT();
  const { speak, speaking } = useTTS();
  const [stage, setStage] = useState('intro'); // intro | ready | listening | scored | aifeedback
  const [score, setScore] = useState(null);
  const [aiFeedback, setAiFeedback] = useState(null);
  const [loadingAI, setLoadingAI] = useState(false);
  const [attempts, setAttempts] = useState(0);

  const handleListen = () => {
    setStage('listening');
    startListening();
  };

  const handleStop = async () => {
    stopListening();
    await new Promise(r => setTimeout(r, 500));
    const s = scorePronunciation(transcript, target);
    setScore(s);
    setAttempts(a => a + 1);
    dispatch({ type: 'SET_SPEAKING_SCORE', payload: s });
    setStage('scored');
  };

  const handleAIFeedback = async () => {
    if (!transcript) return;
    setLoadingAI(true);
    setStage('aifeedback');
    const fb = await getAIFeedback(transcript, prompt, topic);
    setAiFeedback(fb);
    setLoadingAI(false);
  };

  const handleTryAgain = () => {
    setStage('ready');
    setScore(null);
    setAiFeedback(null);
  };

  const canComplete = score !== null && score >= 40;
  const scoreColor = score >= 80 ? '#10b981' : score >= 60 ? '#f59e0b' : '#ef4444';
  const scoreLabel = score >= 80 ? 'Excellent! 🌟' : score >= 60 ? 'Good! 👍' : score >= 40 ? 'Keep Trying! 💪' : 'Try Again! 🎯';

  return (
    <div className="speaking-step">
      {stage === 'intro' && (
        <div className="speaking-intro">
          <div className="speaking-prompt-card glass-card">
            <p className="speaking-section-label">📝 Your Task</p>
            <p className="speaking-prompt-text">{prompt}</p>
          </div>

          <div className="speaking-target-card">
            <p className="speaking-section-label">💡 Example Answer</p>
            <p className="speaking-target-text">{target}</p>
            <button className="speak-btn mt-8" onClick={() => speak(target)}>
              {speaking ? '🔊 Playing...' : '▶ Hear Example'}
            </button>
          </div>

          <div className="speaking-tips">
            <p>🎯 Tips for better speaking:</p>
            <ul>
              <li>Speak clearly and at a normal pace</li>
              <li>Don't worry about making mistakes</li>
              <li>Use the example as a guide, not a script</li>
            </ul>
          </div>

          <button className="step-complete-btn" onClick={() => setStage('ready')}>
            I'm Ready to Speak! 🎤
          </button>
        </div>
      )}

      {(stage === 'ready' || stage === 'listening') && (
        <div className="speaking-record">
          <div className="speaking-prompt-mini glass-card">
            <p>{prompt}</p>
          </div>

          <div className={`mic-container ${listening ? 'pulsing' : ''}`}>
            <button
              className={`mic-btn ${listening ? 'recording' : ''}`}
              onClick={listening ? handleStop : handleListen}
            >
              {listening ? '⏹' : '🎤'}
            </button>
            {listening && <p className="mic-status-text">Listening... tap to stop</p>}
            {!listening && <p className="mic-status-text">Tap to speak</p>}
          </div>

          {transcript && (
            <div className="transcript-box glass-card">
              <p className="transcript-label">You said:</p>
              <p className="transcript-text">"{transcript}"</p>
            </div>
          )}

          {error && <p className="speech-error">{error}</p>}
        </div>
      )}

      {stage === 'scored' && score !== null && (
        <div className="speaking-scored">
          <div className="score-circle" style={{ '--score-color': scoreColor }}>
            <svg viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="45" fill="none" stroke="var(--bg-card)" strokeWidth="8" />
              <circle
                cx="50" cy="50" r="45" fill="none"
                stroke={scoreColor} strokeWidth="8"
                strokeDasharray={`${2.83 * score} ${2.83 * (100 - score)}`}
                strokeLinecap="round"
                transform="rotate(-90 50 50)"
                style={{ transition: 'stroke-dasharray 1s ease' }}
              />
            </svg>
            <div className="score-center">
              <span className="score-number">{score}%</span>
              <span className="score-label-txt">{scoreLabel}</span>
            </div>
          </div>

          {transcript && (
            <div className="transcript-box glass-card">
              <p className="transcript-label">You said:</p>
              <p className="transcript-text">"{transcript}"</p>
            </div>
          )}

          <div className="score-actions">
            <button className="score-action-btn secondary" onClick={handleTryAgain}>
              🔁 Try Again {attempts > 1 ? `(${attempts}x)` : ''}
            </button>
            <button className="score-action-btn primary" onClick={handleAIFeedback} disabled={!transcript}>
              🤖 Get AI Feedback
            </button>
          </div>

          {canComplete && (
            <button className="step-complete-btn" onClick={onComplete}>
              ✓ Complete Speaking Exercise
            </button>
          )}
          {!canComplete && (
            <p className="score-min-notice">Score at least 40% to continue. You can do it! 💪</p>
          )}
        </div>
      )}

      {stage === 'aifeedback' && (
        <div className="ai-feedback">
          <div className="ai-header">
            <span className="ai-avatar">🤖</span>
            <div>
              <p className="ai-title">AI Coach Feedback</p>
              <p className="ai-sub">Your personal speaking coach</p>
            </div>
          </div>

          {loadingAI ? (
            <div className="ai-loading">
              <div className="ai-loading-dots">
                <span /><span /><span />
              </div>
              <p>Analyzing your English...</p>
            </div>
          ) : aiFeedback && (
            <div className="ai-content">
              <div className="ai-feedback-card glass-card">
                <p className="ai-feedback-text">{aiFeedback.feedback}</p>
              </div>

              {aiFeedback.correction && (
                <div className="ai-correction glass-card">
                  <p className="ai-section-label">📝 Correction</p>
                  <p>{aiFeedback.correction}</p>
                </div>
              )}

              {aiFeedback.better_phrase && (
                <div className="ai-better glass-card">
                  <p className="ai-section-label">✨ Better Way to Say It</p>
                  <p>{aiFeedback.better_phrase}</p>
                </div>
              )}

              {aiFeedback.scores && (
                <div className="ai-scores">
                  {Object.entries(aiFeedback.scores).map(([key, val]) => (
                    <div key={key} className="ai-score-row">
                      <span className="ai-score-key">{key.charAt(0).toUpperCase() + key.slice(1)}</span>
                      <div className="ai-score-track">
                        <div className="ai-score-bar" style={{ width: `${val}%` }} />
                      </div>
                      <span className="ai-score-val">{val}%</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          <div className="score-actions">
            <button className="score-action-btn secondary" onClick={handleTryAgain}>
              🔁 Try Again
            </button>
          </div>

          <button className="step-complete-btn" onClick={onComplete}>
            ✓ Complete Speaking Exercise
          </button>
        </div>
      )}
    </div>
  );
}
