import React, { useState } from 'react';
import { useTTS } from '../../hooks/useSpeech';
import './Steps.css';

export default function ListeningStep({ text, onComplete }) {
  const [played, setPlayed] = useState(0);
  const [speed, setSpeed] = useState(0.85);
  const { speak, speaking, stop } = useTTS();

  const handlePlay = () => {
    speak(text, { rate: speed });
    setPlayed(p => p + 1);
  };

  const sentences = text.split(/(?<=[.!?])\s+/);

  return (
    <div className="listening-step">
      <div className="listening-card glass-card">
        <div className="listening-wave">
          {[...Array(12)].map((_, i) => (
            <div
              key={i}
              className={`wave-bar ${speaking ? 'animating' : ''}`}
              style={{ animationDelay: `${i * 0.08}s`, height: `${20 + Math.random() * 30}px` }}
            />
          ))}
        </div>

        <div className="listening-text">
          {sentences.map((s, i) => (
            <p key={i} className="listening-sentence">{s}</p>
          ))}
        </div>
      </div>

      <div className="listening-controls">
        <div className="speed-selector">
          <p className="speed-label">Speed</p>
          {[0.6, 0.85, 1.0].map(s => (
            <button
              key={s}
              className={`speed-btn ${speed === s ? 'active' : ''}`}
              onClick={() => setSpeed(s)}
            >
              {s === 0.6 ? '🐢 Slow' : s === 0.85 ? '🚶 Normal' : '🏃 Fast'}
            </button>
          ))}
        </div>

        <button
          className={`play-listen-btn ${speaking ? 'playing' : ''}`}
          onClick={speaking ? stop : handlePlay}
        >
          {speaking ? '⏹ Stop' : `▶ ${played === 0 ? 'Play Audio' : 'Play Again'}`}
        </button>
      </div>

      {played > 0 && (
        <div className="listened-tip">
          💡 Tip: Listen 2-3 times and try to follow along with the text!
        </div>
      )}

      <button
        className="step-complete-btn"
        onClick={onComplete}
        disabled={played === 0}
      >
        {played === 0 ? 'Listen to the audio first' : '✓ Complete Listening Exercise'}
      </button>
    </div>
  );
}
