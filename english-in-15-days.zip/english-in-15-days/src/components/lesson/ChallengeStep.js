import React, { useState } from 'react';
import './Steps.css';

export default function ChallengeStep({ challenge, dayNum, onComplete }) {
  const [accepted, setAccepted] = useState(false);
  const [done, setDone] = useState(false);

  return (
    <div className="challenge-step">
      <div className="challenge-banner">
        <div className="challenge-icon">⚡</div>
        <h3 className="challenge-title">Daily Challenge</h3>
        <p className="challenge-sub">Day {dayNum} Real-World Task</p>
      </div>

      <div className="challenge-card glass-card">
        <p className="challenge-text">{challenge}</p>
      </div>

      <div className="challenge-why glass-card">
        <p className="challenge-why-title">💡 Why this matters</p>
        <p className="challenge-why-text">
          Real-world practice is the fastest way to become fluent.
          Even 5 minutes of real English use builds more confidence
          than an hour of studying alone!
        </p>
      </div>

      <div className="challenge-checklist">
        <button
          className={`challenge-check-btn ${accepted ? 'checked' : ''}`}
          onClick={() => setAccepted(!accepted)}
        >
          {accepted ? '☑' : '☐'} I accept this challenge!
        </button>
        <button
          className={`challenge-check-btn ${done ? 'checked' : ''}`}
          onClick={() => setDone(!done)}
        >
          {done ? '☑' : '☐'} I completed the challenge!
        </button>
      </div>

      <div className="challenge-xp-preview">
        <span>🏆 Completing today earns you</span>
        <span className="challenge-xp">+100 XP + Day {dayNum} Badge</span>
      </div>

      <button
        className="step-complete-btn"
        onClick={onComplete}
        disabled={!accepted}
      >
        🎉 Complete Day {dayNum}!
      </button>

      {!accepted && (
        <p style={{ textAlign: 'center', fontSize: 13, color: 'var(--text-muted)', marginTop: 8 }}>
          Accept the challenge to complete the day
        </p>
      )}
    </div>
  );
}
